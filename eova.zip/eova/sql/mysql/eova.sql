/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50045
Source Host           : localhost:3306
Source Database       : eova

Target Server Type    : MYSQL
Target Server Version : 50045
File Encoding         : 65001

Date: 2021-06-25 22:55:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for eova_button
-- ----------------------------
DROP TABLE IF EXISTS `eova_button`;
CREATE TABLE `eova_button` (
  `id` int(11) NOT NULL auto_increment,
  `menu_code` varchar(255) NOT NULL COMMENT '菜单Code',
  `name` varchar(255) NOT NULL COMMENT '按钮名称',
  `icon` varchar(255) default NULL COMMENT '图标',
  `ui` varchar(255) default NULL COMMENT '按钮UI路径',
  `bs` varchar(500) default NULL COMMENT '按钮BS路径',
  `order_num` int(11) default '0' COMMENT '排序号',
  `group_num` int(11) default '0' COMMENT '分组号',
  `is_base` tinyint(1) default '0' COMMENT '是否基础功能',
  `is_hide` tinyint(1) default '0' COMMENT '是否删除',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1394 DEFAULT CHARSET=utf8 COMMENT='EOVA操作按钮';

-- ----------------------------
-- Records of eova_button
-- ----------------------------
INSERT INTO `eova_button` VALUES ('1', 'eova_menu', '查询', null, 'query', null, '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('2', 'eova_menu', '新增', null, '/eova/template/singletree/btn/add.html', null, '1', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('3', 'eova_menu', '修改', null, '/eova/template/singletree/btn/update.html', null, '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('4', 'eova_menu', '删除', null, '/eova/template/singletree/btn/delete.html', null, '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('5', 'eova_menu', '查看', null, '/eova/template/singletree/btn/detail.html', null, '4', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('6', 'eova_menu', '隐藏', null, '/eova/template/singletree/btn/hide.html', null, '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('7', 'eova_menu', '导出菜单脚本', 'eova-icon387', '/eova/menu/btn/export.html', null, '12', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('8', 'eova_menu', '基本功能设置', 'eova-icon297', '/eova/menu/btn/fun.html', null, '11', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('9', 'eova_menu', '新增功能', 'eova-icon724', '/eova/menu/btn/add.html', null, '0', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('20', 'eova_object', '查询', null, 'query', null, '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('21', 'eova_object', '新增', null, '/eova/template/masterslave/btn1/add.html', null, '1', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('22', 'eova_object', '修改', null, '/eova/template/masterslave/btn1/update.html', null, '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('23', 'eova_object', '删除', null, '/eova/template/masterslave/btn1/delete.html', null, '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('24', 'eova_object', '查看', null, '/eova/template/masterslave/btn1/detail.html', null, '4', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('25', 'eova_object', '字段新增', null, '/eova/template/masterslave/btn2/add.html', null, '0', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('26', 'eova_object', '字段修改', null, '/eova/template/masterslave/btn2/update.html', null, '1', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('27', 'eova_object', '字段删除', null, '/eova/template/masterslave/btn2/delete.html', null, '2', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('28', 'eova_object', '导出元数据脚本', 'eova-icon387', '/eova/meta/btn/export.html', null, '11', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('29', 'eova_object', '导入元数据', 'eova-icon387', '/eova/meta/btn/import.html', null, '10', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('30', 'eova_object', '覆盖同步', 'eova-icon391', '/eova/meta/btn/override.html', null, '12', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('31', 'eova_object', '增量同步', 'eova-icon391', '/eova/meta/btn/syncnew.html', null, '13', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('32', 'eova_object', '复制元数据', 'eova-icon382', '/eova/meta/btn/copy.html', null, '14', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('33', 'eova_object', '添加虚拟字段', 'eova-icon380', '/eova/template/common/btn/input.html', '/meta/addVirtualField', '15', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('40', 'eova_button', '查询', null, 'query', null, '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('41', 'eova_button', '新增', null, '/eova/template/treetogrid/btn/add.html', null, '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('42', 'eova_button', '修改', null, '/eova/template/treetogrid/btn/update.html', null, '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('43', 'eova_button', '删除', null, '/eova/template/treetogrid/btn/delete.html', null, '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('44', 'eova_button', '查看', null, '/eova/template/treetogrid/btn/detail.html', null, '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('45', 'eova_button', '导出按钮脚本', 'eova-icon387', '/eova/button/btn/export.html', null, '7', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('80', 'eova_task', '查询', null, 'query', null, '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('81', 'eova_task', '新增', null, '/eova/template/single/btn/add.html', null, '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('82', 'eova_task', '修改', null, '/eova/template/single/btn/update.html', null, '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('83', 'eova_task', '删除', null, '/eova/template/single/btn/delete.html', null, '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('84', 'eova_task', '查看', null, '/eova/template/single/btn/detail.html', null, '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('85', 'eova_task', '导入', null, '/eova/template/single/btn/import.html', null, '5', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('86', 'eova_task', '启动任务', 'eova-icon288', '/eova/task/btn/start.html', null, '10', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('87', 'eova_task', '暂停任务', 'eova-icon287', '/eova/task/btn/stop.html', null, '11', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('88', 'eova_task', '立即运行一次', 'eova-icon290', '/eova/task/btn/trigger.html', null, '12', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('90', 'eova_code', '查询', null, 'query', null, '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('100', 'sys_log', '查询', null, 'query', '/single_grid/list/sys_log;/grid/query/eova_log_code*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('101', 'sys_log', '新增', null, '/eova/template/single/btn/add.html', '/form/add/eova_log_code*;/form/doAdd/eova_log_code', '1', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('102', 'sys_log', '修改', null, '/eova/template/single/btn/update.html', '/form/update/eova_log_code*;/form/doUpdate/eova_log_code', '2', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('103', 'sys_log', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/eova_log_code', '3', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('104', 'sys_log', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/eova_log_code*', '4', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('105', 'sys_log', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/sys_log;/single_grid/doImportXls/sys_log', '5', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('110', 'sys_auth_role', '查询', null, 'query', '/single_grid/list/sys_auth_role;/grid/query/eova_role_code*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('111', 'sys_auth_role', '新增', null, '/eova/template/single/btn/add.html', '/form/add/eova_role_code*;/form/doAdd/eova_role_code', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('112', 'sys_auth_role', '修改', null, '/eova/template/single/btn/update.html', '/form/update/eova_role_code*;/form/doUpdate/eova_role_code', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('113', 'sys_auth_role', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/eova_role_code', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('114', 'sys_auth_role', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/eova_role_code*', '4', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('115', 'sys_auth_role', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/sys_auth_role;/single_grid/doImportXls/sys_auth_role', '5', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('116', 'sys_auth_role', '权限分配', 'eova-icon523', '/eova/auth/btn/roleChoose.html', '/auth/toRoleChoose/*;/auth/getFunJson;/auth/getRoleFunJson/*;/auth/roleChoose/*', '10', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('129', 'sys_users', '修改密码', 'eova-icon572', '/eova/user/btn/pwd.html', '/user/pwd/*', '7', '0', '0', '0');
INSERT INTO `eova_button` VALUES ('1132', 'sys_users', '查询', null, 'query', '/single_grid/list/sys_users;/grid/query/eova_user_code*;/grid/export/eova_user_code*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1133', 'sys_users', '新增', null, '/eova/template/single/btn/add.html', '/form/add/eova_user_code*;/form/doAdd/eova_user_code', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1134', 'sys_users', '修改', null, '/eova/template/single/btn/update.html', '/form/update/eova_user_code*;/form/doUpdate/eova_user_code', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1135', 'sys_users', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/eova_user_code', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1136', 'sys_users', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/eova_user_code*', '4', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1137', 'sys_users', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/sys_users;/single_grid/doImportXls/sys_users', '5', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1138', 'sys_users', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/eova_user_code', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1139', 'work_time', '查询', null, 'query', '/single_grid/list/work_time;/grid/query/work_time*;/grid/export/work_time*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1140', 'work_time', '新增', null, '/eova/template/single/btn/add.html', '/form/add/work_time*;/form/doAdd/work_time', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1141', 'work_time', '修改', null, '/eova/template/single/btn/update.html', '/form/update/work_time*;/form/doUpdate/work_time', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1142', 'work_time', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/work_time', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1143', 'work_time', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/work_time*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1144', 'work_time', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/work_time;/single_grid/doImportXls/work_time', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1145', 'work_time', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/work_time', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1175', 'user', '查询', null, 'query', '/master_slave_grid/list/user;/grid/query/user*;/grid/export/user*;/grid/query/teacher*;/grid/export/teacher*;/grid/query/student*;/grid/export/student*;/grid/query/admin*;/grid/export/admin*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1176', 'user', '新增', null, '/eova/template/masterslave/btn1/add.html', '/form/add/user*;/form/doAdd/user', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1177', 'user', '修改', null, '/eova/template/masterslave/btn1/update.html', '/form/update/user*;/form/doUpdate/user', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1178', 'user', '删除', null, '/eova/template/masterslave/btn1/delete.html', '/grid/delete/user', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1179', 'user', '查看', null, '/eova/template/masterslave/btn1/detail.html', '/form/detail/user*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1180', 'user', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/user', '5', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1181', 'user', '教师新增', null, '/eova/template/masterslave/btn2/add.html', '/form/add/teacher*;/form/doAdd/teacher', '0', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1182', 'user', '教师修改', null, '/eova/template/masterslave/btn2/update.html', '/form/update/teacher*;/form/doUpdate/teacher', '1', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1183', 'user', '教师删除', null, '/eova/template/masterslave/btn2/delete.html', '/grid/delete/teacher', '2', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1184', 'user', '教师查看', null, '/eova/template/masterslave/btn2/detail.html', '/form/detail/teacher*', '3', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1185', 'user', '教师隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/teacher', '4', '1', '1', '1');
INSERT INTO `eova_button` VALUES ('1186', 'user', '学生新增', null, '/eova/template/masterslave/btn2/add.html', '/form/add/student*;/form/doAdd/student', '0', '2', '1', '0');
INSERT INTO `eova_button` VALUES ('1187', 'user', '学生修改', null, '/eova/template/masterslave/btn2/update.html', '/form/update/student*;/form/doUpdate/student', '1', '2', '1', '0');
INSERT INTO `eova_button` VALUES ('1188', 'user', '学生删除', null, '/eova/template/masterslave/btn2/delete.html', '/grid/delete/student', '2', '2', '1', '0');
INSERT INTO `eova_button` VALUES ('1189', 'user', '学生查看', null, '/eova/template/masterslave/btn2/detail.html', '/form/detail/student*', '3', '2', '1', '0');
INSERT INTO `eova_button` VALUES ('1190', 'user', '学生隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/student', '4', '2', '1', '1');
INSERT INTO `eova_button` VALUES ('1191', 'user', '管理员新增', null, '/eova/template/masterslave/btn2/add.html', '/form/add/admin*;/form/doAdd/admin', '0', '3', '1', '0');
INSERT INTO `eova_button` VALUES ('1192', 'user', '管理员修改', null, '/eova/template/masterslave/btn2/update.html', '/form/update/admin*;/form/doUpdate/admin', '1', '3', '1', '0');
INSERT INTO `eova_button` VALUES ('1193', 'user', '管理员删除', null, '/eova/template/masterslave/btn2/delete.html', '/grid/delete/admin', '2', '3', '1', '0');
INSERT INTO `eova_button` VALUES ('1194', 'user', '管理员查看', null, '/eova/template/masterslave/btn2/detail.html', '/form/detail/admin*', '3', '3', '1', '0');
INSERT INTO `eova_button` VALUES ('1195', 'user', '管理员隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/admin', '4', '3', '1', '1');
INSERT INTO `eova_button` VALUES ('1221', 'class_info', '查询', null, 'query', '/single_grid/list/class_info;/grid/query/class_info*;/grid/export/class_info*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1222', 'class_info', '新增', null, '/eova/template/single/btn/add.html', '/form/add/class_info*;/form/doAdd/class_info', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1223', 'class_info', '修改', null, '/eova/template/single/btn/update.html', '/form/update/class_info*;/form/doUpdate/class_info', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1224', 'class_info', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/class_info', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1225', 'class_info', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/class_info*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1226', 'class_info', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/class_info;/single_grid/doImportXls/class_info', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1227', 'class_info', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/class_info', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1228', 'subject', '查询', null, 'query', '/single_grid/list/subject;/grid/query/subject*;/grid/export/subject*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1229', 'subject', '新增', null, '/eova/template/single/btn/add.html', '/form/add/subject*;/form/doAdd/subject', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1230', 'subject', '修改', null, '/eova/template/single/btn/update.html', '/form/update/subject*;/form/doUpdate/subject', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1231', 'subject', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/subject', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1232', 'subject', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/subject*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1233', 'subject', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/subject;/single_grid/doImportXls/subject', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1234', 'subject', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/subject', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1235', 'grade', '查询', null, 'query', '/single_grid/list/grade;/grid/query/grade*;/grid/export/grade*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1236', 'grade', '新增', null, '/eova/template/single/btn/add.html', '/form/add/grade*;/form/doAdd/grade', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1237', 'grade', '修改', null, '/eova/template/single/btn/update.html', '/form/update/grade*;/form/doUpdate/grade', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1238', 'grade', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/grade', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1239', 'grade', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/grade*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1240', 'grade', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/grade;/single_grid/doImportXls/grade', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1241', 'grade', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/grade', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1242', 'roles', '查询', null, 'query', '/single_grid/list/roles;/grid/query/roles*;/grid/export/roles*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1243', 'roles', '新增', null, '/eova/template/single/btn/add.html', '/form/add/roles*;/form/doAdd/roles', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1244', 'roles', '修改', null, '/eova/template/single/btn/update.html', '/form/update/roles*;/form/doUpdate/roles', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1245', 'roles', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/roles', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1246', 'roles', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/roles*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1247', 'roles', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/roles;/single_grid/doImportXls/roles', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1248', 'roles', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/roles', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1249', 'project', '查询', null, 'query', '/single_grid/list/project;/grid/query/project*;/grid/export/project*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1250', 'project', '新增', null, '/eova/template/single/btn/add.html', '/form/add/project*;/form/doAdd/project', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1251', 'project', '修改', null, '/eova/template/single/btn/update.html', '/form/update/project*;/form/doUpdate/project', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1252', 'project', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/project', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1253', 'project', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/project*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1254', 'project', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/project;/single_grid/doImportXls/project', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1255', 'project', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/project', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1256', 'project_from', '查询', null, 'query', '/single_grid/list/project_from;/grid/query/project_from*;/grid/export/project_from*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1257', 'project_from', '新增', null, '/eova/template/single/btn/add.html', '/form/add/project_from*;/form/doAdd/project_from', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1258', 'project_from', '修改', null, '/eova/template/single/btn/update.html', '/form/update/project_from*;/form/doUpdate/project_from', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1259', 'project_from', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/project_from', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1260', 'project_from', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/project_from*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1261', 'project_from', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/project_from;/single_grid/doImportXls/project_from', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1262', 'project_from', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/project_from', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1263', 'ktbg', '查询', null, 'query', '/single_grid/list/ktbg;/grid/query/ktbg*;/grid/export/ktbg*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1264', 'ktbg', '新增', null, '/eova/template/single/btn/add.html', '/form/add/ktbg*;/form/doAdd/ktbg', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1265', 'ktbg', '修改', null, '/eova/template/single/btn/update.html', '/form/update/ktbg*;/form/doUpdate/ktbg', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1266', 'ktbg', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/ktbg', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1267', 'ktbg', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/ktbg*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1268', 'ktbg', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/ktbg;/single_grid/doImportXls/ktbg', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1269', 'ktbg', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/ktbg', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1270', 'zqjc', '查询', null, 'query', '/single_grid/list/zqjc;/grid/query/zqjc*;/grid/export/zqjc*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1271', 'zqjc', '新增', null, '/eova/template/single/btn/add.html', '/form/add/zqjc*;/form/doAdd/zqjc', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1272', 'zqjc', '修改', null, '/eova/template/single/btn/update.html', '/form/update/zqjc*;/form/doUpdate/zqjc', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1273', 'zqjc', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/zqjc', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1274', 'zqjc', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/zqjc*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1275', 'zqjc', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/zqjc;/single_grid/doImportXls/zqjc', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1276', 'zqjc', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/zqjc', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1277', 'inform', '查询', null, 'query', '/single_grid/list/inform;/grid/query/inform*;/grid/export/inform*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1278', 'inform', '新增', null, '/eova/template/single/btn/add.html', '/form/add/inform*;/form/doAdd/inform', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1279', 'inform', '修改', null, '/eova/template/single/btn/update.html', '/form/update/inform*;/form/doUpdate/inform', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1280', 'inform', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/inform', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1281', 'inform', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/inform*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1282', 'inform', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/inform;/single_grid/doImportXls/inform', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1283', 'inform', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/inform', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1284', 'down', '查询', null, 'query', '/single_grid/list/down;/grid/query/down*;/grid/export/down*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1285', 'down', '新增', null, '/eova/template/single/btn/add.html', '/form/add/down*;/form/doAdd/down', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1286', 'down', '修改', null, '/eova/template/single/btn/update.html', '/form/update/down*;/form/doUpdate/down', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1287', 'down', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/down', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1288', 'down', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/down*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1289', 'down', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/down;/single_grid/doImportXls/down', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1290', 'down', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/down', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1291', 'lunwen', '查询', null, 'query', '/single_grid/list/lunwen;/grid/query/lunwen*;/grid/export/lunwen*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1292', 'lunwen', '新增', null, '/eova/template/single/btn/add.html', '/form/add/lunwen*;/form/doAdd/lunwen', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1293', 'lunwen', '修改', null, '/eova/template/single/btn/update.html', '/form/update/lunwen*;/form/doUpdate/lunwen', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1294', 'lunwen', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/lunwen', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1295', 'lunwen', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/lunwen*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1296', 'lunwen', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/lunwen;/single_grid/doImportXls/lunwen', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1297', 'lunwen', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/lunwen', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1298', 'yansou', '查询', null, 'query', '/single_grid/list/yansou;/grid/query/yansou*;/grid/export/yansou*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1299', 'yansou', '新增', null, '/eova/template/single/btn/add.html', '/form/add/yansou*;/form/doAdd/yansou', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1300', 'yansou', '修改', null, '/eova/template/single/btn/update.html', '/form/update/yansou*;/form/doUpdate/yansou', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1301', 'yansou', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/yansou', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1302', 'yansou', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/yansou*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1303', 'yansou', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/yansou;/single_grid/doImportXls/yansou', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1304', 'yansou', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/yansou', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1312', 'teacher_info', '查询', null, 'query', '/single_grid/list/teacher_info;/grid/query/teacher*;/grid/export/teacher*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1313', 'teacher_info', '新增', null, '/eova/template/single/btn/add.html', '/form/add/teacher*;/form/doAdd/teacher', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1314', 'teacher_info', '修改', null, '/eova/template/single/btn/update.html', '/form/update/teacher*;/form/doUpdate/teacher', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1315', 'teacher_info', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/teacher', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1316', 'teacher_info', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/teacher*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1317', 'teacher_info', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/teacher_info;/single_grid/doImportXls/teacher_info', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1318', 'teacher_info', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/teacher', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1319', 'admin', '查询', null, 'query', '/single_grid/list/admin;/grid/query/admin*;/grid/export/admin*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1320', 'admin', '新增', null, '/eova/template/single/btn/add.html', '/form/add/admin*;/form/doAdd/admin', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1321', 'admin', '修改', null, '/eova/template/single/btn/update.html', '/form/update/admin*;/form/doUpdate/admin', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1322', 'admin', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/admin', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1323', 'admin', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/admin*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1324', 'admin', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/admin;/single_grid/doImportXls/admin', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1325', 'admin', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/admin', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1326', 'dept', '查询', null, 'query', '/single_grid/list/dept;/grid/query/dept*;/grid/export/dept*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1327', 'dept', '新增', null, '/eova/template/single/btn/add.html', '/form/add/dept*;/form/doAdd/dept', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1328', 'dept', '修改', null, '/eova/template/single/btn/update.html', '/form/update/dept*;/form/doUpdate/dept', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1329', 'dept', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/dept', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1330', 'dept', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/dept*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1331', 'dept', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/dept;/single_grid/doImportXls/dept', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1332', 'dept', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/dept', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1333', 'dabian', '查询', null, 'query', '/single_grid/list/dabian;/grid/query/dabian*;/grid/export/dabian*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1334', 'dabian', '新增', null, '/eova/template/single/btn/add.html', '/form/add/dabian*;/form/doAdd/dabian', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1335', 'dabian', '修改', null, '/eova/template/single/btn/update.html', '/form/update/dabian*;/form/doUpdate/dabian', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1336', 'dabian', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/dabian', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1337', 'dabian', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/dabian*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1338', 'dabian', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/dabian;/single_grid/doImportXls/dabian', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1339', 'dabian', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/dabian', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1358', 'student_info', '查询', null, 'query', '/master_slave_grid/list/student_info;/grid/query/student*;/grid/export/student*;/grid/query/dabian*;/grid/export/dabian*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1359', 'student_info', '新增', null, '/eova/template/masterslave/btn1/add.html', '/form/add/student*;/form/doAdd/student', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1360', 'student_info', '修改', null, '/eova/template/masterslave/btn1/update.html', '/form/update/student*;/form/doUpdate/student', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1361', 'student_info', '删除', null, '/eova/template/masterslave/btn1/delete.html', '/grid/delete/student', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1362', 'student_info', '查看', null, '/eova/template/masterslave/btn1/detail.html', '/form/detail/student*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1363', 'student_info', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/student', '5', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1364', 'student_info', '答辩成绩新增', null, '/eova/template/masterslave/btn2/add.html', '/form/add/dabian*;/form/doAdd/dabian', '0', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1365', 'student_info', '答辩成绩修改', null, '/eova/template/masterslave/btn2/update.html', '/form/update/dabian*;/form/doUpdate/dabian', '1', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1366', 'student_info', '答辩成绩删除', null, '/eova/template/masterslave/btn2/delete.html', '/grid/delete/dabian', '2', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1367', 'student_info', '答辩成绩查看', null, '/eova/template/masterslave/btn2/detail.html', '/form/detail/dabian*', '3', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1368', 'student_info', '答辩成绩隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/dabian', '4', '1', '1', '1');
INSERT INTO `eova_button` VALUES ('1369', 'mangsheng', '查询', null, 'query', '/master_slave_grid/list/mangsheng;/grid/query/mangsheng*;/grid/export/mangsheng*;/grid/query/student*;/grid/export/student*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1370', 'mangsheng', '新增', null, '/eova/template/masterslave/btn1/add.html', '/form/add/mangsheng*;/form/doAdd/mangsheng', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1371', 'mangsheng', '修改', null, '/eova/template/masterslave/btn1/update.html', '/form/update/mangsheng*;/form/doUpdate/mangsheng', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1372', 'mangsheng', '删除', null, '/eova/template/masterslave/btn1/delete.html', '/grid/delete/mangsheng', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1373', 'mangsheng', '查看', null, '/eova/template/masterslave/btn1/detail.html', '/form/detail/mangsheng*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1374', 'mangsheng', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/mangsheng', '5', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1375', 'mangsheng', '学生新增', null, '/eova/template/masterslave/btn2/add.html', '/form/add/student*;/form/doAdd/student', '0', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1376', 'mangsheng', '学生修改', null, '/eova/template/masterslave/btn2/update.html', '/form/update/student*;/form/doUpdate/student', '1', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1377', 'mangsheng', '学生删除', null, '/eova/template/masterslave/btn2/delete.html', '/grid/delete/student', '2', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1378', 'mangsheng', '学生查看', null, '/eova/template/masterslave/btn2/detail.html', '/form/detail/student*', '3', '1', '1', '0');
INSERT INTO `eova_button` VALUES ('1379', 'mangsheng', '学生隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/student', '4', '1', '1', '1');
INSERT INTO `eova_button` VALUES ('1380', 'yansou_teacher', '查询', null, 'query', '/single_grid/list/yansou_teacher;/grid/query/yansou_teacher*;/grid/export/yansou_teacher*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1381', 'yansou_teacher', '新增', null, '/eova/template/single/btn/add.html', '/form/add/yansou_teacher*;/form/doAdd/yansou_teacher', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1382', 'yansou_teacher', '修改', null, '/eova/template/single/btn/update.html', '/form/update/yansou_teacher*;/form/doUpdate/yansou_teacher', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1383', 'yansou_teacher', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/yansou_teacher', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1384', 'yansou_teacher', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/yansou_teacher*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1385', 'yansou_teacher', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/yansou_teacher;/single_grid/doImportXls/yansou_teacher', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1386', 'yansou_teacher', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/yansou_teacher', '6', '0', '1', '1');
INSERT INTO `eova_button` VALUES ('1387', 'mdb', '查询', null, 'query', '/single_grid/list/mdb;/grid/query/mdb*;/grid/export/mdb*', '0', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1388', 'mdb', '新增', null, '/eova/template/single/btn/add.html', '/form/add/mdb*;/form/doAdd/mdb', '1', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1389', 'mdb', '修改', null, '/eova/template/single/btn/update.html', '/form/update/mdb*;/form/doUpdate/mdb', '2', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1390', 'mdb', '删除', null, '/eova/template/single/btn/delete.html', '/grid/delete/mdb', '3', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1391', 'mdb', '查看', null, '/eova/template/single/btn/detail.html', '/form/detail/mdb*', '4', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1392', 'mdb', '导入', null, '/eova/template/single/btn/import.html', '/single_grid/importXls/mdb;/single_grid/doImportXls/mdb', '5', '0', '1', '0');
INSERT INTO `eova_button` VALUES ('1393', 'mdb', '隐藏', null, '/eova/template/single/btn/hide.html', '/grid/hide/mdb', '6', '0', '1', '1');

-- ----------------------------
-- Table structure for eova_dict
-- ----------------------------
DROP TABLE IF EXISTS `eova_dict`;
CREATE TABLE `eova_dict` (
  `id` int(11) NOT NULL auto_increment,
  `value` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `object` varchar(50) NOT NULL,
  `field` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COMMENT='EOVA字典';

-- ----------------------------
-- Records of eova_dict
-- ----------------------------
INSERT INTO `eova_dict` VALUES ('1', 'main', '默认', 'eova_object', 'data_source');
INSERT INTO `eova_dict` VALUES ('2', 'eova', 'EOVA', 'eova_object', 'data_source');
INSERT INTO `eova_dict` VALUES ('40', '1', '新增', 'eova_log', 'type');
INSERT INTO `eova_dict` VALUES ('41', '2', '修改', 'eova_log', 'type');
INSERT INTO `eova_dict` VALUES ('42', '3', '删除', 'eova_log', 'type');
INSERT INTO `eova_dict` VALUES ('70', '0', '正常', 'eova_field', 'update_status');
INSERT INTO `eova_dict` VALUES ('71', '10', '只读', 'eova_field', 'update_status');
INSERT INTO `eova_dict` VALUES ('72', '20', '隐藏', 'eova_field', 'update_status');
INSERT INTO `eova_dict` VALUES ('73', '50', '禁用', 'eova_field', 'update_status');
INSERT INTO `eova_dict` VALUES ('100', '0', '暂停', 'eova_job', 'state');
INSERT INTO `eova_dict` VALUES ('101', '1', '运行', 'eova_job', 'state');

-- ----------------------------
-- Table structure for eova_field
-- ----------------------------
DROP TABLE IF EXISTS `eova_field`;
CREATE TABLE `eova_field` (
  `id` int(11) NOT NULL auto_increment COMMENT 'ID',
  `object_code` varchar(50) NOT NULL,
  `fieldnum` int(11) default '0' COMMENT '表单分组序号',
  `order_num` int(4) default '9' COMMENT '排序索引',
  `fieldset` varchar(255) default '' COMMENT '表单分组',
  `table_name` varchar(255) default NULL COMMENT '字段表名',
  `en` varchar(50) NOT NULL COMMENT '英文名',
  `cn` varchar(50) NOT NULL COMMENT '中文名',
  `is_auto` tinyint(1) default '0' COMMENT '主键是否自增长',
  `type` varchar(10) default '文本框' COMMENT '控件类型',
  `exp` varchar(800) default NULL COMMENT '控件表达式',
  `is_query` tinyint(1) default '0' COMMENT '是否可查询',
  `is_show` tinyint(1) default '1' COMMENT '是否可显示',
  `is_disable` tinyint(1) default '0' COMMENT '是否禁用',
  `is_order` tinyint(1) default '1' COMMENT '是否可排序',
  `is_add` tinyint(1) default '1' COMMENT '是否可新增字段(V1.6废弃)',
  `is_update` tinyint(1) default '1' COMMENT '是否可修改字段(V1.6废弃)',
  `is_edit` tinyint(1) default '1' COMMENT '是否可编辑字段',
  `is_required` tinyint(1) default '1' COMMENT '是否必填',
  `is_multiple` tinyint(1) default '0' COMMENT '是否多选项',
  `placeholder` varchar(255) default NULL COMMENT '输入提示',
  `validator` varchar(255) default NULL COMMENT 'UI校验表达式',
  `defaulter` varchar(255) default NULL COMMENT '默认值表达式',
  `formatter` varchar(2000) default NULL COMMENT '格式化器',
  `width` int(4) default '130' COMMENT '控件宽度',
  `height` int(4) default '20' COMMENT '控件高度',
  `config` varchar(2000) default NULL COMMENT '拓展配置',
  `add_status` int(3) default '0' COMMENT '状态：0=正常，10=只读，20=隐藏，50=禁用',
  `update_status` int(3) default '0' COMMENT '状态：0=正常，10=只读，20=隐藏，50=禁用',
  `data_type` int(5) default '12' COMMENT '数据类型',
  `data_type_name` varchar(20) default 'VARCHAR' COMMENT '数据类型名称',
  `data_size` int(2) default '1' COMMENT '整数位长度',
  `data_decimal` int(2) default '0' COMMENT '小数位长度',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3292 DEFAULT CHARSET=utf8 COMMENT='EOVA元字段';

-- ----------------------------
-- Records of eova_field
-- ----------------------------
INSERT INTO `eova_field` VALUES ('1', 'eova_meta_template', '0', '0', '', '', 'meta', 'meta', '0', '文本框', '', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '50', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('2', 'eova_object_code', '0', '1', '基础信息', null, 'id', 'ID', '1', '自增框', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3', 'eova_object_code', '0', '2', '基础信息', null, 'code', '编码', '0', '文本框', null, '1', '1', '0', '1', '1', '0', '0', '1', '0', null, 'eovacode', null, null, '200', '20', null, '0', '10', '12', 'VARCHAR', '100', '0');
INSERT INTO `eova_field` VALUES ('4', 'eova_object_code', '0', '3', '基础信息', null, 'name', '名称', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '1', '0', null, null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '100', '0');
INSERT INTO `eova_field` VALUES ('5', 'eova_object_code', '0', '4', '基础信息', null, 'view_name', '视图', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '70', '20', null, '50', '10', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('6', 'eova_object_code', '0', '5', '基础信息', null, 'table_name', '数据表', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '80', '20', null, '50', '10', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('7', 'eova_object_code', '0', '6', '基础信息', null, 'pk_name', '主键', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '0', '1', '0', null, null, null, null, '70', '20', null, '50', '10', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('8', 'eova_object_code', '0', '7', '基础信息', null, 'data_source', '数据源', '0', '下拉框', 'select value ID,name CN from eova_dict where object = \'eova_object\' and field = \'data_source\';ds=eova', '0', '1', '0', '1', '1', '1', '0', '1', '0', null, null, 'main', null, '70', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('9', 'eova_object_code', '1', '8', '功能配置', null, 'is_single', '单选/多选', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', null, null, '1', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('10', 'eova_object_code', '1', '9', '功能配置', null, 'is_show_num', '显示行号', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', null, null, '1', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('11', 'eova_object_code', '1', '10', '功能配置', null, 'default_order', '默认排序', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', '例如：id desc (默认按ID倒序)', null, null, null, '70', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('12', 'eova_object_code', '1', '11', '功能配置', null, 'filter', '过滤条件', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', '例如：status = 1 (只显示状态为1的数据)', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '500', '0');
INSERT INTO `eova_field` VALUES ('13', 'eova_object_code', '1', '13', '功能配置', null, 'diy_js', '依赖JS', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', '自定义JS文件路径', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('14', 'eova_object_code', '1', '8', '功能配置', null, 'is_celledit', '行内编辑', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', null, null, '0', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('15', 'eova_object_code', '1', '12', '功能配置', null, 'biz_intercept', '业务拦截器', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', '继承：com.eova.core.meta.MetaObjectIntercept', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('16', 'eova_object_code', '1', '9', '功能配置', null, 'is_first_load', '是否初始加载', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '1', null, '130', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('17', 'eova_object_code', '1', '17', '功能配置', null, 'view_sql', '视图SQL', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '100', null, '50', '10', '12', 'VARCHAR', '1000', '0');
INSERT INTO `eova_field` VALUES ('18', 'eova_object_code', '1', '18', '功能配置', null, 'config', '拓展配置', '0', 'JSON框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '300', null, '0', '0', '12', 'VARCHAR', '2000', '0');
INSERT INTO `eova_field` VALUES ('50', 'eova_field_code', '0', '1', '', null, 'id', 'ID', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('51', 'eova_field_code', '0', '2', '', null, 'object_code', '对象编码', '0', '查找框', 'select code 编码,name 名称 from eova_object where id > 999 order by id desc;ds=eova', '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '150', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('52', 'eova_field_code', '0', '9', '', null, 'en', '字段名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '0', '0', '数据库的字段名', null, null, null, '120', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('53', 'eova_field_code', '0', '8', '', null, 'cn', '中文名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '0', '0', '字段对应的中文描述', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('54', 'eova_field_code', '0', '24', '', null, 'is_auto', '自增长', '0', '布尔框', null, '0', '0', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('55', 'eova_field_code', '0', '10', '', null, 'data_type_name', '字段类型', '0', '文本框', '', '0', '0', '0', '0', '1', '1', '0', '0', '0', null, null, null, null, '70', '20', null, '0', '10', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('56', 'eova_field_code', '0', '11', '', null, 'type', '控件类型', '0', '下拉框', 'select value ID,name CN from eova_widget;ds=eova', '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '文本框', null, '70', '20', null, '0', '0', '12', 'VARCHAR', '10', '0');
INSERT INTO `eova_field` VALUES ('57', 'eova_field_code', '0', '6', '', null, 'order_num', '排序', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '9', null, '50', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('58', 'eova_field_code', '0', '51', '', null, 'exp', '表达式', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', '查找框和下拉框需需要表达式', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '800', '0');
INSERT INTO `eova_field` VALUES ('59', 'eova_field_code', '0', '25', '', null, 'is_query', '快速查询', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '60', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('60', 'eova_field_code', '0', '26', '', null, 'is_show', '列表显示', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '1', null, '60', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('61', 'eova_field_code', '0', '32', '', null, 'is_order', '允许排序', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '1', null, '60', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('62', 'eova_field_code', '0', '28', '', null, 'is_add', '允许新增', '0', '布尔框', null, '0', '0', '0', '0', '0', '0', '0', '0', '0', null, null, '1', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('63', 'eova_field_code', '0', '29', '', null, 'is_update', '允许修改', '0', '布尔框', null, '0', '0', '0', '0', '0', '0', '0', '0', '0', null, null, '1', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('64', 'eova_field_code', '0', '31', '', null, 'is_required', '是否必填', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '1', null, '60', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('65', 'eova_field_code', '0', '36', '', null, 'defaulter', '默认值', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', '缺省默认值', null, null, null, '110', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('66', 'eova_field_code', '0', '20', '', null, 'width', '列宽度', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '130', null, '50', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('67', 'eova_field_code', '0', '21', '', null, 'height', '高度', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '20', null, '50', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('68', 'eova_field_code', '0', '33', '', null, 'is_multiple', '是否有多值', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('69', 'eova_field_code', '0', '30', '', null, 'is_edit', '单元格编辑', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '1', null, '75', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('70', 'eova_field_code', '0', '35', '', null, 'placeholder', '输入提示', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', 'input的placeholder属性', null, null, null, '60', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('71', 'eova_field_code', '0', '54', '', null, 'formatter', '格式化器', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', '格式化的JS,参考EasyUI datagrid formatter', null, null, null, '130', '150', null, '0', '0', '12', 'VARCHAR', '2000', '0');
INSERT INTO `eova_field` VALUES ('72', 'eova_field_code', '0', '53', '', null, 'validator', 'UI校验器', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', 'UI校验规则', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('73', 'eova_field_code', '0', '27', '', null, 'is_disable', '是否禁用', '0', '布尔框', null, '0', '0', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '70', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('74', 'eova_field_code', '0', '23', '', null, 'update_status', '更新状态', '0', '下拉框', 'select value ID,name CN from eova_dict where object = \'eova_field\' and field = \'update_status\';ds=eova', '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '60', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('75', 'eova_field_code', '0', '22', '', null, 'add_status', '新增状态', '0', '下拉框', 'select value ID,name CN from eova_dict where object = \'eova_field\' and field = \'update_status\';ds=eova', '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '60', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('76', 'eova_field_code', '0', '7', '', null, 'fieldset', '分组名称', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, null, null, '90', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('77', 'eova_field_code', '0', '5', '', null, 'fieldnum', '分组号', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '70', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('78', 'eova_field_code', '0', '6', '', null, 'table_name', '字段表名', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '100', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('79', 'eova_field_code', '0', '999', '', null, 'config', '拓展配置', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '2000', '0');
INSERT INTO `eova_field` VALUES ('80', 'eova_field_code', '0', '30', '', null, 'data_type', '数据类型', '0', '文本框', null, '0', '0', '0', '1', '1', '1', '0', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('81', 'eova_field_code', '0', '32', '', null, 'data_size', '整数位长度', '0', '文本框', null, '0', '0', '0', '1', '1', '1', '0', '0', '0', null, null, '1', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('82', 'eova_field_code', '0', '33', '', null, 'data_decimal', '小数位长度', '0', '文本框', null, '0', '0', '0', '1', '1', '1', '0', '0', '0', null, null, '0', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('100', 'eova_menu_code', '0', '1', '', null, 'id', 'ID', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '0', '0', '0', null, null, null, 'function(value, row, index, field) { \r\n    return \'<b style=\"color:red\">\' + row.value + \'</b>\'; \r\n}', '40', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('101', 'eova_menu_code', '0', '4', '', null, 'code', '编码', '0', '文本框', null, '1', '1', '1', '1', '1', '0', '0', '0', '0', null, 'eovacode', null, null, '200', '20', null, '0', '10', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('102', 'eova_menu_code', '0', '1', '', null, 'name', '名称', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '200', '20', null, '0', '0', '12', 'VARCHAR', '100', '0');
INSERT INTO `eova_field` VALUES ('103', 'eova_menu_code', '0', '2', '', null, 'type', '类型', '0', '文本框', null, '0', '1', '0', '1', '1', '0', '0', '0', '0', null, null, null, null, '120', '20', null, '0', '10', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('104', 'eova_menu_code', '0', '6', '', null, 'iconskip', '图标', '0', '图标框', null, '0', '0', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('105', 'eova_menu_code', '0', '9', '', null, 'order_num', '序号', '0', '文本框', null, '0', '0', '0', '1', '1', '1', '0', '0', '0', null, null, '0', null, '30', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('106', 'eova_menu_code', '0', '9', '', null, 'parent_id', '父节点', '0', '下拉树', 'select id ID,parent_id PID, name NAME from eova_menu;ds=eova', '0', '0', '0', '1', '1', '0', '0', '0', '0', null, null, '0', null, '100', '20', null, '50', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('107', 'eova_menu_code', '0', '16', '', null, 'is_hide', '是否隐藏', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '130', '20', null, '10', '10', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('109', 'eova_menu_code', '0', '12', '', null, 'biz_intercept', '业务拦截器', '0', '文本域', null, '0', '0', '0', '1', '1', '1', '0', '0', '0', '继承：模版业务拦截器', null, null, null, '300', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('110', 'eova_menu_code', '0', '15', '', null, 'url', '自定义功能', '0', '文本域', null, '0', '0', '0', '1', '1', '0', '0', '0', '0', null, null, null, null, '130', '20', null, '0', '50', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('111', 'eova_menu_code', '0', '11', '', null, 'filter', '过滤条件', '0', '文本域', '', '0', '1', '0', '1', '1', '1', '1', '0', '0', '例如：status = 1 (只显示状态为1的数据)', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '500', '0');
INSERT INTO `eova_field` VALUES ('112', 'eova_menu_code', '0', '13', '', null, 'diy_js', '依赖JS', '0', '文本域', '', '0', '0', '0', '1', '1', '1', '1', '0', '0', '自定义JS文件路径', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('113', 'eova_menu_code', '0', '17', '', null, 'open', '是否展开', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '1', null, '130', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('114', 'eova_menu_code', '0', '18', '', null, 'config', '菜单配置JSON', '0', 'JSON框', null, '0', '0', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '400', null, '0', '0', '12', 'VARCHAR', '500', '0');
INSERT INTO `eova_field` VALUES ('150', 'eova_button_code', '1', '30', '', null, 'is_hide', '是否隐藏', '0', '布尔框', null, '0', '1', '0', '1', '0', '1', '1', '0', '0', null, null, '0', null, '60', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('151', 'eova_button_code', '1', '3', '', null, 'icon', 'ICON', '0', '图标框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, null, '', '30', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('152', 'eova_button_code', '1', '1', '', null, 'id', 'ID', '1', '自增框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, null, 'function(value,row,index,field){if(value){return\'<span class=\"tree-icon tree-file \'+value+\'\"></span>\'}return value}', '50', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('153', 'eova_button_code', '1', '2', '', null, 'menu_code', '菜单编码', '0', '查找框', 'select code 菜单编码,name 菜单名称 from eova_menu where 1=1;ds=eova', '0', '1', '0', '1', '1', '1', '0', '0', '0', null, 'eovacode', null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('154', 'eova_button_code', '1', '4', '', null, 'name', '功能名称', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('155', 'eova_button_code', '1', '10', '', null, 'ui', 'UI路径', '0', '文本域', null, '1', '1', '0', '1', '1', '1', '1', '0', '0', null, null, null, null, '280', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('156', 'eova_button_code', '1', '20', '', null, 'bs', 'BS路径', '0', '文本域', null, '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '250', '20', null, '0', '0', '12', 'VARCHAR', '500', '0');
INSERT INTO `eova_field` VALUES ('157', 'eova_button_code', '1', '6', '', null, 'order_num', '序号', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', '按钮的显示顺序', 'digits', '0', null, '50', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('158', 'eova_button_code', '1', '7', '', null, 'group_num', '分组号', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', 'Toolbar分组号', 'digits', '0', null, '50', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('159', 'eova_button_code', '1', '8', '', null, 'is_base', '是否基础功能', '0', '布尔框', null, '0', '0', '0', '1', '0', '0', '0', '0', '0', null, null, '0', null, '130', '20', null, '0', '0', '-7', 'BIT', '0', '0');
INSERT INTO `eova_field` VALUES ('201', 'eova_user_code', '1', '2', '', null, 'login_id', '登录帐号', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '1', '0', null, null, null, null, '136', '20', null, '0', '0', '12', 'VARCHAR', '30', '0');
INSERT INTO `eova_field` VALUES ('202', 'eova_user_code', '1', '4', '', null, 'login_pwd', '登录密码', '0', '文本框', null, '0', '0', '0', '0', '1', '0', '0', '1', '0', null, null, null, null, '130', '20', null, '0', '50', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('203', 'eova_user_code', '1', '3', '', null, 'rid', '角色', '0', '下拉框', 'select id ID,name CN from eova_role where lv > ${user.role.lv};ds=eova', '1', '1', '0', '1', '1', '1', '0', '1', '0', null, null, '0', null, '137', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('204', 'eova_user_code', '1', '1', '', null, 'id', 'ID', '1', '自增框', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '71', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('220', 'eova_role_code', '1', '0', '', null, 'id', 'ID', '1', '自增框', null, '0', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('221', 'eova_role_code', '1', '1', '', null, 'name', '角色名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '1', '0', null, null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('222', 'eova_role_code', '1', '3', '', null, 'info', '角色描述', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '0', '1', '0', null, null, null, null, '230', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('223', 'eova_role_code', '1', '2', '', null, 'lv', '权限级别', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '0', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('260', 'eova_log_code', '1', '1', '', null, 'id', 'id', '1', '自增框', '', '0', '1', '0', '1', '1', '1', '0', '0', '0', '', '', null, '', '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('261', 'eova_log_code', '1', '2', '', null, 'user_id', '操作用户', '0', '查找框', 'select id UID,login_id 用户名 from eova_user where 1=1;ds=eova', '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('262', 'eova_log_code', '1', '3', '', '', 'type', '日志类型', '0', '下拉框', 'select value ID,name CN from eova_dict where object = \'eova_log\' and field = \'type\';ds=eova', '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('263', 'eova_log_code', '1', '4', '', null, 'ip', '操作IP', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '0', '0', '0', null, null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('264', 'eova_log_code', '1', '5', '', null, 'info', '详情', '0', '文本框', '', '1', '1', '0', '0', '0', '0', '0', '1', '0', '', '', null, '', '330', '20', null, '0', '0', '12', 'VARCHAR', '500', '0');
INSERT INTO `eova_field` VALUES ('265', 'eova_log_code', '1', '6', '', null, 'create_time', '操作时间', '0', '时间框', '', '1', '1', '0', '0', '0', '0', '0', '1', '0', null, null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '1', '0');
INSERT INTO `eova_field` VALUES ('280', 'eova_task_code', '1', '1', '', null, 'id', 'ID', '1', '自增框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, null, null, '50', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('281', 'eova_task_code', '1', '2', '', null, 'state', '状态', '0', '下拉框', 'select value ID,name CN from eova_dict where object = \'eova_job\' and field = \'state\';ds=eova', '1', '1', '0', '1', '0', '0', '0', '1', '0', null, null, '0', 'function(value, row, index, field) { \r\n	return \'<a target=\"_blank\" href=\"http://g.cn\" style=\"color:blue\">\' + value + \'</a>\' \r\n}', '50', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('282', 'eova_task_code', '1', '3', '', null, 'name', '名称', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', '任务简称', null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('283', 'eova_task_code', '1', '4', '', null, 'exp', '表达式', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', 'Quartz表达式', '', null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('284', 'eova_task_code', '1', '5', '', null, 'clazz', '实现类', '0', '文本域', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', 'Job实现类', null, null, null, '230', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('285', 'eova_task_code', '1', '6', '', null, 'info', '说明', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', '任务的详细描述', null, null, null, '330', '50', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('2132', 'user_info_code', '1', '1', '基本信息', null, 'id', 'id', '0', '查找框', 'select id ID,login_id 帐号 from eova_user;ds=eova', '0', '0', '0', '1', '1', '1', '1', '0', '0', '', null, null, null, '130', '20', null, '20', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('2133', 'user_info_code', '1', '2', '基本信息', null, 'rid', '冗余角色ID', '0', '文本框', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', null, null, '0', null, '130', '20', null, '50', '50', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('2134', 'user_info_code', '1', '5', '基本信息', null, 'status', '状态', '0', '下拉框', 'select value ID , name CN from dicts where object = \'users\' and field = \'status\' or object = \'${user.id}\'', '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '0', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('2135', 'user_info_code', '1', '6', '基本信息', null, 'nickname', '昵称', '0', '文本框', '', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '30', '0');
INSERT INTO `eova_field` VALUES ('2136', 'user_info_code', '1', '7', '基本信息', null, 'mobile', '联系手机', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, null, null, '130', '20', null, '0', '0', '12', 'VARCHAR', '11', '0');
INSERT INTO `eova_field` VALUES ('2137', 'user_info_code', '2', '8', '地区信息', null, 'province', '省', '0', '下拉框', 'select id ID,name CN from area where lv = 1', '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, null, null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('2138', 'user_info_code', '2', '9', '地区信息', null, 'city', '市', '0', '下拉框', 'select id ID,name CN from area where lv = 2', '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, null, null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('2139', 'user_info_code', '2', '10', '地区信息', null, 'region', '区', '0', '下拉框', 'select id ID,name CN from area where lv = 3', '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, null, null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('2140', 'user_info_code', '1', '30', '基本信息', null, 'create_time', '创建时间', '0', '时间框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, null, null, '130', '20', null, '50', '10', '93', 'TIMESTAMP', '19', '0');
INSERT INTO `eova_field` VALUES ('3132', 'work_time', '0', '10', '', null, 'work_time_id', '主键,id', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3133', 'work_time', '0', '20', '', null, 'work_time_info', '描述', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3134', 'work_time', '0', '30', '', null, 'work_time_start', '开始时间', '0', '时间框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '93', 'DATETIME', '19', '0');
INSERT INTO `eova_field` VALUES ('3135', 'work_time', '0', '40', '', null, 'work_time_end', '结束时间', '0', '时间框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '93', 'DATETIME', '19', '0');
INSERT INTO `eova_field` VALUES ('3136', 'class_info', '0', '10', '', null, 'class_id', '主键,id', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3137', 'class_info', '0', '20', '', null, 'class_name', '班级名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '30', '0');
INSERT INTO `eova_field` VALUES ('3138', 'class_info', '0', '30', '', '', 'grade_id', '外键,年级', '0', '下拉框', 'select grade_id Id,grade_name CN from grade;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3139', 'class_info', '0', '40', '', '', 'subject_id', '外键,专业名', '0', '下拉框', 'select subject_id ID,subject_name CN from subject;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3140', 'subject', '0', '10', '', null, 'subject_id', '主键,id', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3141', 'subject', '0', '20', '', null, 'subject_name', '专业名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '30', '0');
INSERT INTO `eova_field` VALUES ('3142', 'grade', '0', '10', '', null, 'grade_id', '主键,id', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3143', 'grade', '0', '20', '', null, 'grade_name', '年级名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3144', 'admin', '0', '10', '', '', 'admin_id', '管理员id', '0', '文本框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '20', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3145', 'admin', '0', '20', '', '', 'user_id', '用户名', '0', '下拉框', 'select user_id ID,user_name CN from user where user_roles=3;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3155', 'teacher', '0', '10', '', '', 'teacher_id', '导师id', '0', '文本框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '20', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3156', 'teacher', '0', '20', '', null, 'teacher_describe', '导师描述', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3157', 'teacher', '0', '30', '', '', 'teacher_project_num', '导师出题数', '0', '文本域', '', '0', '1', '0', '1', '1', '1', '1', '0', '0', '教师出题数最多为8个', '', '0', '', '130', '20', '', '0', '0', '1', 'CHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3159', 'teacher', '0', '50', '', '', 'user_id', '用户名', '0', '下拉框', 'select user_id ID,user_name CN from user where user_roles=1;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3160', 'teacher', '0', '60', '', '', 'dept_id', '部门', '0', '下拉框', 'select dept_id Id,dept_name CN from dept;ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3161', 'teacher', '0', '70', '', '', 'zhicheng', '职称', '0', '文本框', '', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '副教授', '', '130', '20', '', '0', '0', '1', 'CHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3162', 'user', '0', '10', '', '', 'user_id', '主键,用户id', '0', '文本框', '', '0', '0', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '20', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3163', 'user', '0', '20', '', null, 'user_name', '用户名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3164', 'user', '0', '30', '', null, 'user_account', '用户登录账号', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3165', 'user', '0', '40', '', null, 'user_password', '密码', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3166', 'user', '0', '50', '', null, 'user_tel', '用户电话号', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '1', 'CHAR', '12', '0');
INSERT INTO `eova_field` VALUES ('3167', 'user', '0', '60', '', '', 'user_gender', '性别', '0', '下拉框', 'select value ID,name CN from dicts where object=\'user\' and field=\'user_gender\';ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '0', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3168', 'user', '0', '70', '', null, 'user_portrait', '头像图片路径', '0', '图片框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3169', 'user', '0', '80', '', '', 'user_roles', '用户角色', '0', '下拉框', 'select roles_id ID, roles_name CN from roles;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3170', 'roles', '0', '10', '', null, 'roles_id', '主键,角色id', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3171', 'roles', '0', '20', '', null, 'roles_name', '角色名（导师，学生，管理员，超级管理员）', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '1', 'CHAR', '10', '0');
INSERT INTO `eova_field` VALUES ('3176', 'dept', '0', '10', '', '', 'dept_id', '部门id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3177', 'dept', '0', '20', '', null, 'dept_name', '部门科室名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('3178', 'my_dicts', '0', '10', '', null, 'id', 'id', '1', '自增框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3179', 'my_dicts', '0', '20', '', null, 'value', '字典值', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('3180', 'my_dicts', '0', '30', '', null, 'name', '字典中文', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('3181', 'my_dicts', '0', '40', '', null, 'object', '表名', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('3182', 'my_dicts', '0', '50', '', null, 'field', '字段名', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('3183', 'my_dicts', '0', '60', '', null, 'ext', '扩展Json', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3184', 'project', '0', '10', '', null, 'project_id', '主键,课题id', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3185', 'project', '0', '20', '', null, 'project_name', '课题名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '50', '0');
INSERT INTO `eova_field` VALUES ('3186', 'project', '0', '30', '', null, 'project_describe', '课题表述', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3187', 'project', '0', '40', '', '', 'project_from_id', '课题来源', '0', '下拉框', 'select project_from_id ID,project_from_name CN from project_from;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '1', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3188', 'project', '0', '50', '', '', 'teacher_id', '导师', '0', '下拉框', 'select teacher.teacher_id ID,user.user_name CN from teacher,user where teacher.user_id=user.user_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3189', 'project', '0', '60', '', '', 'student_id', '学生', '0', '下拉框', 'select student.student_id ID,user.user_name CN from student,user where user.user_id=student.user_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3190', 'project_from', '0', '10', '', null, 'project_from_id', '主键,id', '1', '自增框', null, '0', '0', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3191', 'project_from', '0', '20', '', '', 'project_from_name', '课题来源', '0', '文本框', '', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3192', 'ktbg', '0', '10', '', '', 'ktbg_id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3193', 'ktbg', '0', '20', '', null, 'column1', '综述', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3194', 'ktbg', '0', '30', '', null, 'column2', '思路及方法', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3195', 'ktbg', '0', '40', '', '', 'student_id', '学生', '0', '下拉框', 'select student.student_id ID,user.user_name CN from student,user where student.user_id=user.user_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3196', 'ktbg', '0', '50', '', '', 'ktbg_status', '教师评审意见', '0', '下拉框', 'select value ID,name CN from dicts where object=\'ktbg\' and field=\'ktbg_status\';ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3197', 'zqjc', '0', '10', '', '', 'zqjc_id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3198', 'zqjc', '0', '20', '', '', 'column1', '已完成内容', '0', '文本域', '', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3199', 'zqjc', '0', '30', '', null, 'column2', '未完成内容及原因', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3200', 'zqjc', '0', '40', '', null, 'column3', '指导老师意见', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3201', 'zqjc', '0', '50', '', null, 'column4', '备注', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3202', 'zqjc', '0', '60', '', '', 'student_id', '学生', '0', '下拉框', 'select student.student_id ID,user.user_name CN from student,user where student.user_id=user.user_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3203', 'inform', '0', '10', '', '', 'inform_id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3204', 'inform', '0', '20', '', null, 'inform_title', '通知公告标题', '0', '文本域', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3205', 'inform', '0', '30', '', null, 'inform_body', '通知公告主体', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3206', 'inform', '0', '40', '', null, 'is_attachment', '是否有附件(0否1有)', '0', '布尔框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '0', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3207', 'inform', '0', '50', '', null, 'attachment_path', '附件地址', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3208', 'inform', '0', '60', '', null, 'create_date', '创建时间', '0', '时间框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '93', 'DATETIME', '19', '0');
INSERT INTO `eova_field` VALUES ('3209', 'inform', '0', '70', '', '', 'admin_id', '管理员', '0', '下拉框', 'select admin.admin_id ID,user.user_name CN from admin,user where admin.user_id=user.user_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3210', 'down', '0', '10', '', '', 'down_id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3211', 'down', '0', '20', '', null, 'down_title', '资源标题', '0', '文本域', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3212', 'down', '0', '30', '', '', 'down_path', '资源下载地址', '0', '文本域', '', '0', '1', '0', '1', '1', '1', '1', '1', '0', '填写下载文件名即可,并将需下载的文件放入应用根目录/WEB-INF/file', '', '', '', '130', '20', '', '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3213', 'down', '0', '40', '', null, 'create_date', '创建时间', '0', '时间框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '93', 'DATETIME', '19', '0');
INSERT INTO `eova_field` VALUES ('3214', 'down', '0', '50', '', '', 'admin_id', '管理员', '0', '下拉框', 'select admin.admin_id ID,user.user_name CN from admin,user where admin.user_id=user.user_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '12', 'VARCHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3215', 'lunwen', '0', '10', '', '', 'lunwen_id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3216', 'lunwen', '0', '20', '', null, 'lunwen_name', '论文名', '0', '文本框', null, '1', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3217', 'lunwen', '0', '30', '', null, 'lunwen_path', '论文上传路径', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '1', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3218', 'lunwen', '0', '40', '', null, 'lunwen_date', '论文上传时间', '0', '时间框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '93', 'DATETIME', '19', '0');
INSERT INTO `eova_field` VALUES ('3219', 'lunwen', '0', '50', '', '', 'student_id', '学生', '0', '下拉框', 'select student.student_id ID,user.user_name CN from student,user where student.user_id=user.user_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3220', 'lunwen', '0', '60', '', '', 'lunwen_status', '论文审核状态', '0', '下拉框', 'select value ID,name CN from dicts where object=\'lunwen\' and field=\'lunwen_status\';ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3232', 'mangsheng', '0', '10', '', '', 'id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3233', 'mangsheng', '0', '20', '', '', 'student_id', '学生', '0', '下拉框', 'SELECT student.student_id ID,user.user_name CN FROM user,student,yansou_team where user.user_id=student.user_id and student.yansou_team_id=yansou_team.yansou_team_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3234', 'mangsheng', '0', '30', '', null, 'mangsheng_evaluate', '盲审结论', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3236', 'dabian', '0', '10', '', '', 'id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3237', 'dabian', '0', '20', '', '', 'student_id', '学生', '0', '下拉框', 'SELECT student.student_id ID,user.user_name CN FROM user,student,yansou_team where user.user_id=student.user_id and student.yansou_team_id=yansou_team.yansou_team_id;ds=main', '1', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3238', 'dabian', '0', '30', '', null, 'dabian_score', '答辩成绩', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3251', 'yansou', '0', '10', '', '', 'yansou_team_id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3252', 'yansou', '0', '20', '', '', 'yansou_team_name', '验收小组编号', '0', '文本框', '', '0', '1', '0', '1', '1', '1', '1', '1', '0', '小组名,例如:验收一组', '', '', '', '130', '20', '', '0', '0', '12', 'VARCHAR', '20', '0');
INSERT INTO `eova_field` VALUES ('3253', 'yansou_teacher', '0', '10', '', '', 'id', 'id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3254', 'yansou_teacher', '0', '20', '', '', 'yansou_team_id', '验收组', '0', '下拉框', 'select yansou_team_id ID,yansou_team_name CN from yansou_team;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3255', 'yansou_teacher', '0', '30', '', '', 'teacher_id', '教师', '0', '下拉框', 'select teacher.teacher_id ID,user.user_name CN from teacher,user where teacher.user_id=user.user_id;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3256', 'yansou_teacher', '0', '40', '', '', 'is_leader', '是否为组长', '0', '下拉框', 'select value ID,name CN from dicts where object=\'yansou\' and field=\'is_leader\'', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3257', 'mdb', '0', '10', '', '', 'mdb_id', '免答辩id', '1', '自增框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '50', '20', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3258', 'mdb', '0', '20', '', null, 'column1', '申请理由', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3259', 'mdb', '0', '30', '', null, 'column2', '教师意见', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3260', 'mdb', '0', '40', '', null, 'column3', '学校学位委员会意见', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3261', 'mdb', '0', '50', '', '', 'student_id', '学生', '0', '下拉框', 'select student.student_id ID,user.user_name CN from student,user where student.user_id=user.user_id;ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3262', 'mdb', '0', '60', '', '', 'mdb_status', '免答辩状态', '0', '下拉框', 'select value ID,name CN from dicts where object=\'mdb\' and field=\'mdb_status\';ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3282', 'student', '0', '10', '', '', 'student_id', '学生id', '0', '文本框', '', '0', '0', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '20', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3283', 'student', '0', '20', '', '', 'project_num', '是否已选择课题', '0', '下拉框', 'select value ID,name CN from dicts where object=\'student\' and field=\'project_num\';ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '0', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3284', 'student', '0', '30', '', '', 'good_boy', '是否免答辩', '0', '下拉框', 'select value ID,name CN from dicts where object=\'student\' and field=\'good_boy\';ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '0', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3285', 'student', '0', '40', '', '', 'project_id', '课题', '0', '下拉框', 'select project_id ID, project_name CN from project;ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3286', 'student', '0', '50', '', '', 'teacher_id', '导师', '0', '下拉框', 'select teacher_id ID, user_name CN from teacher,user where user.user_id=teacher.user_id;ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', ' ', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3287', 'student', '0', '60', '', '', 'user_id', '用户名', '0', '下拉框', 'select user_id ID,user_name CN from user where user_roles=2;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '1', 'CHAR', '32', '0');
INSERT INTO `eova_field` VALUES ('3288', 'student', '0', '70', '', '', 'class_id', '班级', '0', '下拉框', 'select class_id ID,class_name CN from class_info;ds=main', '0', '1', '0', '1', '1', '1', '1', '1', '0', '', '', '', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3289', 'student', '0', '80', '', null, 'student_score', '成绩', '0', '文本框', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '4', 'INT', '10', '0');
INSERT INTO `eova_field` VALUES ('3290', 'student', '0', '90', '', null, 'teacher_evaluate', '导师评语(成绩评价)', '0', '文本域', null, '0', '1', '0', '1', '1', '1', '1', '0', '0', null, null, '', null, '130', '20', null, '0', '0', '12', 'VARCHAR', '255', '0');
INSERT INTO `eova_field` VALUES ('3291', 'student', '0', '100', '', '', 'yansou_team_id', '验收小组', '0', '下拉框', 'select yansou_team_id ID,yansou_team_name CN from yansou_team;ds=main', '0', '1', '0', '1', '1', '1', '1', '0', '0', '', '', '0', '', '130', '20', '', '0', '0', '4', 'INT', '10', '0');

-- ----------------------------
-- Table structure for eova_log
-- ----------------------------
DROP TABLE IF EXISTS `eova_log`;
CREATE TABLE `eova_log` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` char(32) NOT NULL COMMENT '操作用户',
  `type` int(11) NOT NULL COMMENT '日志类型',
  `ip` varchar(255) NOT NULL COMMENT '操作IP',
  `info` varchar(500) default NULL COMMENT '操作详情',
  `create_time` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP COMMENT '操作时间',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COMMENT='EOVA操作日志';

-- ----------------------------
-- Records of eova_log
-- ----------------------------
INSERT INTO `eova_log` VALUES ('1', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'user', '2018-04-28 20:04:36');
INSERT INTO `eova_log` VALUES ('2', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1132]', '2018-04-28 20:16:32');
INSERT INTO `eova_log` VALUES ('3', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1132]', '2018-04-28 20:20:10');
INSERT INTO `eova_log` VALUES ('4', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'user[00d8b3523c474575aa3f689b7e596b93]', '2018-04-28 20:20:21');
INSERT INTO `eova_log` VALUES ('5', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'user', '2018-04-28 20:20:45');
INSERT INTO `eova_log` VALUES ('6', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1132]', '2018-04-28 20:46:59');
INSERT INTO `eova_log` VALUES ('7', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3224]', '2018-04-28 20:58:24');
INSERT INTO `eova_log` VALUES ('8', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3224]', '2018-04-28 20:59:54');
INSERT INTO `eova_log` VALUES ('9', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'eova_object_code[1154]', '2018-04-28 21:00:50');
INSERT INTO `eova_log` VALUES ('10', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'eova_object_code[1155]', '2018-04-28 21:01:30');
INSERT INTO `eova_log` VALUES ('11', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'eova_field_code[3224]', '2018-04-28 21:02:54');
INSERT INTO `eova_log` VALUES ('12', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3291]', '2018-04-28 21:04:32');
INSERT INTO `eova_log` VALUES ('13', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3288]', '2018-04-28 21:05:29');
INSERT INTO `eova_log` VALUES ('14', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3287]', '2018-04-28 21:08:14');
INSERT INTO `eova_log` VALUES ('15', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 21:09:49');
INSERT INTO `eova_log` VALUES ('16', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3287]', '2018-04-28 21:10:17');
INSERT INTO `eova_log` VALUES ('17', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3285]', '2018-04-28 21:10:55');
INSERT INTO `eova_log` VALUES ('18', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3284]', '2018-04-28 21:14:37');
INSERT INTO `eova_log` VALUES ('19', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3284]', '2018-04-28 21:14:43');
INSERT INTO `eova_log` VALUES ('20', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3283]', '2018-04-28 21:16:32');
INSERT INTO `eova_log` VALUES ('21', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3282]', '2018-04-28 21:17:01');
INSERT INTO `eova_log` VALUES ('22', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1156]', '2018-04-28 21:17:20');
INSERT INTO `eova_log` VALUES ('23', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3159]', '2018-04-28 21:18:01');
INSERT INTO `eova_log` VALUES ('24', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3145]', '2018-04-28 21:18:16');
INSERT INTO `eova_log` VALUES ('25', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 21:21:34');
INSERT INTO `eova_log` VALUES ('26', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3287]', '2018-04-28 21:22:20');
INSERT INTO `eova_log` VALUES ('27', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 21:23:40');
INSERT INTO `eova_log` VALUES ('28', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1129]', '2018-04-28 21:27:45');
INSERT INTO `eova_log` VALUES ('29', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3144]', '2018-04-28 21:28:12');
INSERT INTO `eova_log` VALUES ('30', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3287]', '2018-04-28 22:05:15');
INSERT INTO `eova_log` VALUES ('31', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3159]', '2018-04-28 22:05:45');
INSERT INTO `eova_log` VALUES ('32', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3145]', '2018-04-28 22:06:44');
INSERT INTO `eova_log` VALUES ('33', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3287]', '2018-04-28 22:07:20');
INSERT INTO `eova_log` VALUES ('34', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3159]', '2018-04-28 22:07:30');
INSERT INTO `eova_log` VALUES ('35', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3145]', '2018-04-28 22:07:37');
INSERT INTO `eova_log` VALUES ('36', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1156]', '2018-04-28 22:25:23');
INSERT INTO `eova_log` VALUES ('37', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'student', '2018-04-28 22:33:08');
INSERT INTO `eova_log` VALUES ('38', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3282]', '2018-04-28 22:33:53');
INSERT INTO `eova_log` VALUES ('39', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3155]', '2018-04-28 22:34:24');
INSERT INTO `eova_log` VALUES ('40', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3144]', '2018-04-28 22:34:38');
INSERT INTO `eova_log` VALUES ('41', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'student[7d722789d911472a9fa66ad96234c4d2]', '2018-04-28 22:35:31');
INSERT INTO `eova_log` VALUES ('42', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3287]', '2018-04-28 22:39:18');
INSERT INTO `eova_log` VALUES ('43', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3159]', '2018-04-28 22:40:03');
INSERT INTO `eova_log` VALUES ('44', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3145]', '2018-04-28 22:40:26');
INSERT INTO `eova_log` VALUES ('45', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 22:43:29');
INSERT INTO `eova_log` VALUES ('46', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1156]', '2018-04-28 22:50:14');
INSERT INTO `eova_log` VALUES ('47', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1129]', '2018-04-28 22:51:12');
INSERT INTO `eova_log` VALUES ('48', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'admin', '2018-04-28 22:51:31');
INSERT INTO `eova_log` VALUES ('49', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'admin[5e1da88385bf476b8563c821d64049dc]', '2018-04-28 22:51:36');
INSERT INTO `eova_log` VALUES ('50', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_object_code[1131]', '2018-04-28 22:51:57');
INSERT INTO `eova_log` VALUES ('51', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 22:52:27');
INSERT INTO `eova_log` VALUES ('52', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'student[36b767a451d344debb597b2d8b1b06ce]', '2018-04-28 22:53:00');
INSERT INTO `eova_log` VALUES ('53', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 22:58:00');
INSERT INTO `eova_log` VALUES ('54', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 22:59:37');
INSERT INTO `eova_log` VALUES ('55', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 23:01:10');
INSERT INTO `eova_log` VALUES ('56', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 23:19:07');
INSERT INTO `eova_log` VALUES ('57', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3286]', '2018-04-28 23:19:45');
INSERT INTO `eova_log` VALUES ('58', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'student[342cbcd411974227bd21cc0b932a4975]', '2018-04-28 23:32:12');
INSERT INTO `eova_log` VALUES ('59', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'student', '2018-04-28 23:35:39');
INSERT INTO `eova_log` VALUES ('60', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'student[b39d59cc2b3c4ea692221a006d6eac57]', '2018-04-28 23:35:52');
INSERT INTO `eova_log` VALUES ('61', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3284]', '2018-04-28 23:36:55');
INSERT INTO `eova_log` VALUES ('62', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'student', '2018-04-28 23:37:09');
INSERT INTO `eova_log` VALUES ('63', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'student[e172cd1d1c4f4a1dbfda3529cc6b3234]', '2018-04-28 23:37:18');
INSERT INTO `eova_log` VALUES ('64', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'student', '2018-04-28 23:37:36');
INSERT INTO `eova_log` VALUES ('65', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'student[d10e520e2b0e40e38ea3df19125b48de]', '2018-04-28 23:39:44');
INSERT INTO `eova_log` VALUES ('66', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3132]', '2018-04-28 23:40:50');
INSERT INTO `eova_log` VALUES ('67', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3136]', '2018-04-28 23:41:06');
INSERT INTO `eova_log` VALUES ('68', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3140]', '2018-04-28 23:41:17');
INSERT INTO `eova_log` VALUES ('69', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3142]', '2018-04-28 23:41:27');
INSERT INTO `eova_log` VALUES ('70', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3162]', '2018-04-28 23:41:41');
INSERT INTO `eova_log` VALUES ('71', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3170]', '2018-04-28 23:41:54');
INSERT INTO `eova_log` VALUES ('72', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3184]', '2018-04-28 23:42:14');
INSERT INTO `eova_log` VALUES ('73', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3190]', '2018-04-28 23:42:24');
INSERT INTO `eova_log` VALUES ('74', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3192]', '2018-04-28 23:42:41');
INSERT INTO `eova_log` VALUES ('75', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3197]', '2018-04-28 23:42:51');
INSERT INTO `eova_log` VALUES ('76', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3203]', '2018-04-28 23:43:06');
INSERT INTO `eova_log` VALUES ('77', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3210]', '2018-04-28 23:43:18');
INSERT INTO `eova_log` VALUES ('78', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3215]', '2018-04-28 23:43:29');
INSERT INTO `eova_log` VALUES ('79', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3176]', '2018-04-28 23:43:43');
INSERT INTO `eova_log` VALUES ('80', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3236]', '2018-04-28 23:43:51');
INSERT INTO `eova_log` VALUES ('81', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3232]', '2018-04-28 23:44:02');
INSERT INTO `eova_log` VALUES ('82', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3251]', '2018-04-28 23:44:18');
INSERT INTO `eova_log` VALUES ('83', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3253]', '2018-04-28 23:44:28');
INSERT INTO `eova_log` VALUES ('84', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3257]', '2018-04-28 23:44:39');
INSERT INTO `eova_log` VALUES ('85', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_menu_code[3]', '2018-05-02 11:02:46');
INSERT INTO `eova_log` VALUES ('86', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3287]', '2018-05-02 11:03:37');
INSERT INTO `eova_log` VALUES ('87', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3159]', '2018-05-02 11:03:59');
INSERT INTO `eova_log` VALUES ('88', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'eova_field_code[3145]', '2018-05-02 11:04:04');
INSERT INTO `eova_log` VALUES ('89', '848572f7312e4470a26257727af2a369', '1', '0:0:0:0:0:0:0:1', 'student', '2018-05-02 11:04:21');
INSERT INTO `eova_log` VALUES ('90', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:05:29');
INSERT INTO `eova_log` VALUES ('91', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:06:19');
INSERT INTO `eova_log` VALUES ('92', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:10:39');
INSERT INTO `eova_log` VALUES ('93', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:11:13');
INSERT INTO `eova_log` VALUES ('94', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:12:13');
INSERT INTO `eova_log` VALUES ('95', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:14:15');
INSERT INTO `eova_log` VALUES ('96', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:16:00');
INSERT INTO `eova_log` VALUES ('97', '848572f7312e4470a26257727af2a369', '2', '0:0:0:0:0:0:0:1', 'user[56058e923178421c91127ed16c8dd008]', '2018-05-02 11:16:31');
INSERT INTO `eova_log` VALUES ('98', '848572f7312e4470a26257727af2a369', '3', '0:0:0:0:0:0:0:1', 'student[3cfb1964712946b5ade2ad3746bf972e]', '2018-05-02 11:28:53');

-- ----------------------------
-- Table structure for eova_menu
-- ----------------------------
DROP TABLE IF EXISTS `eova_menu`;
CREATE TABLE `eova_menu` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(255) NOT NULL COMMENT '编码',
  `name` varchar(100) NOT NULL COMMENT '名称',
  `type` varchar(20) NOT NULL COMMENT '菜单类型',
  `iconskip` varchar(255) default NULL COMMENT '图标',
  `order_num` int(11) default '0' COMMENT '序号',
  `parent_id` int(11) default '0' COMMENT '父节点',
  `open` tinyint(1) default '1' COMMENT '是否展开',
  `biz_intercept` varchar(255) default NULL COMMENT '自定义业务拦截器',
  `url` varchar(255) default NULL COMMENT '自定义URL',
  `config` varchar(500) default NULL COMMENT '菜单配置JSON',
  `diy_js` varchar(255) default NULL COMMENT '依赖JS文件',
  `is_hide` tinyint(1) default '0' COMMENT '是否隐藏',
  `filter` varchar(500) default NULL COMMENT '初始数据过滤条件',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unique_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=1093 DEFAULT CHARSET=utf8 COMMENT='EOVA菜单';

-- ----------------------------
-- Records of eova_menu
-- ----------------------------
INSERT INTO `eova_menu` VALUES ('1', 'eova', '平台维护', 'dir', 'eova-icon169', '3', '0', '0', null, null, null, null, '0', null);
INSERT INTO `eova_menu` VALUES ('3', 'biz', '信息维护', 'dir', 'eova-icon877', '1', '0', '1', '', null, '', '', '0', '');
INSERT INTO `eova_menu` VALUES ('20', 'eova_menu', '菜单管理', 'single_tree', 'eova-icon43', '1', '1', '1', null, null, '{\"objectCode\":\"eova_menu_code\",\"tree\":{\"iconField\":\"iconskip\",\"parentField\":\"parent_id\",\"treeField\":\"name\",\"idField\":\"id\",\"rootPid\":\"0\"}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('21', 'eova_button', '按钮管理', 'tree_grid', 'eova-icon169', '2', '1', '1', '', null, '{\"objectCode\":\"eova_button_code\",\"objectField\":\"menu_code\",\"tree\":{\"iconField\":\"iconskip\",\"idField\":\"id\",\"objectCode\":\"eova_menu_code\",\"objectField\":\"code\",\"parentField\":\"parent_id\",\"treeField\":\"name\",\"rootPid\":\"0\"}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('22', 'eova_object', '元数据管理', 'master_slave_grid', 'eova-icon395', '3', '1', '1', null, null, '{\"fields\":[\"object_code\"],\"objectCode\":\"eova_object_code\",\"objectField\":\"code\",\"objects\":[\"eova_field_code\"]}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('25', 'eova_task', '定时调度', 'single_grid', 'eova-icon280', '4', '1', '1', null, '', '{\"objectCode\":\"eova_task_code\"}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('26', 'eova_code', '神器·宝箱', 'diy', 'eova-icon157', '666', '1', '1', null, '/code', '{}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('900', 'sys', '系统管理', 'dir', 'eova-icon294', '1', '0', '0', null, null, null, null, '0', null);
INSERT INTO `eova_menu` VALUES ('901', 'sys_users', '用户管理', 'single_grid', 'eova-icon518', '0', '900', '1', '', '', '{\"objectCode\":\"eova_user_code\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('902', 'sys_auth_role', '角色管理', 'single_grid', 'eova-icon525', '2', '900', '1', '', null, '{\"objectCode\":\"eova_role_code\"}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('903', 'sys_log', '系统日志', 'single_grid', 'eova-icon1058', '3', '900', '1', '', null, '{\"objectCode\":\"eova_log_code\"}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1000', 'biz_demo', '功能列表', 'dir', 'eova-icon145', '2', '3', '1', '', null, '', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1058', 'work_time', '工作进度', 'single_grid', 'eova-icon50', '1', '1000', '1', '', '', '{\"objectCode\":\"work_time\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1062', 'user', '用户', 'master_slave_grid', 'eova-icon9', '1', '1070', '1', '', '', '{\"fields\":[\"user_id\",\"user_id\",\"user_id\"],\"objectCode\":\"user\",\"objectField\":\"user_id\",\"objects\":[\"teacher\",\"student\",\"admin\"],\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1066', 'class_dir', '班级目录', 'dir', 'eova-icon100', '1', '1000', '1', '', '', '{\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1067', 'class_info', '班级信息', 'single_grid', 'eova-icon9', '1', '1066', '1', null, '', '{\"objectCode\":\"class_info\",\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1068', 'subject', '专业信息', 'single_grid', 'eova-icon9', '1', '1066', '1', null, '', '{\"objectCode\":\"subject\",\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1069', 'grade', '年级信息', 'single_grid', 'eova-icon9', '1', '1066', '1', null, '', '{\"objectCode\":\"grade\",\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1070', 'user_dir', '用户目录', 'dir', 'eova-icon100', '1', '1000', '1', null, '', '{\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1071', 'roles', '角色', 'single_grid', 'eova-icon9', '1', '1070', '1', null, '', '{\"objectCode\":\"roles\",\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1072', 'project', '课题', 'single_grid', 'eova-icon9', '1', '1073', '1', '', '', '{\"objectCode\":\"project\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1073', 'project_dir', '课题目录', 'dir', 'eova-icon100', '1', '1000', '1', null, '', '{\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1074', 'project_from', '课题来源', 'single_grid', 'eova-icon9', '1', '1073', '1', null, '', '{\"objectCode\":\"project_from\",\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1075', 'ktbg', '开题报告', 'single_grid', 'eova-icon50', '1', '1000', '1', '', '', '{\"objectCode\":\"ktbg\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1076', 'zqjc', '中期检查', 'single_grid', 'eova-icon50', '1', '1000', '1', '', '', '{\"objectCode\":\"zqjc\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1077', 'inform', '通知公告', 'single_grid', 'eova-icon50', '1', '1000', '1', '', '', '{\"objectCode\":\"inform\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1078', 'down', '下载文件', 'single_grid', 'eova-icon50', '1', '1000', '1', '', '', '{\"objectCode\":\"down\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1079', 'lunwen', '论文', 'single_grid', 'eova-icon50', '1', '1000', '1', '', '', '{\"objectCode\":\"lunwen\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1080', 'yansou', '验收小组', 'single_grid', 'eova-icon9', '1', '1091', '1', '', '', '{\"objectCode\":\"yansou\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1082', 'teacher_info', '教师信息', 'single_grid', 'eova-icon9', '1', '1070', '1', '', '', '{\"objectCode\":\"teacher\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1083', 'admin', '管理员信息', 'single_grid', 'eova-icon9', '1', '1070', '1', '', '', '{\"objectCode\":\"admin\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1084', 'dept', '部门信息', 'single_grid', 'eova-icon9', '1', '1000', '1', '', '', '{\"objectCode\":\"dept\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1085', 'dabian', '答辩成绩', 'single_grid', 'eova-icon9', '1', '1000', '1', null, '', '{\"objectCode\":\"dabian\",\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1088', 'student_info', '学生信息', 'master_slave_grid', 'eova-icon9', '1', '1070', '1', null, '', '{\"fields\":[\"student_id\"],\"objectCode\":\"student\",\"objectField\":\"student_id\",\"objects\":[\"dabian\"],\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1089', 'mangsheng', '盲审信息', 'master_slave_grid', 'eova-icon9', '1', '1000', '1', null, '', '{\"fields\":[\"student_id\"],\"objectCode\":\"mangsheng\",\"objectField\":\"student_id\",\"objects\":[\"student\"],\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1090', 'yansou_teacher', '验收小组成员', 'single_grid', 'eova-icon9', '1', '1091', '1', '', '', '{\"objectCode\":\"yansou_teacher\",\"params\":{}}', '', '0', '');
INSERT INTO `eova_menu` VALUES ('1091', 'yansou_dir', '验收目录', 'dir', 'eova-icon100', '1', '1000', '1', null, '', '{\"params\":{}}', null, '0', null);
INSERT INTO `eova_menu` VALUES ('1092', 'mdb', '免答辩管理', 'single_grid', 'eova-icon9', '1', '1000', '1', null, '', '{\"objectCode\":\"mdb\",\"params\":{}}', null, '0', null);

-- ----------------------------
-- Table structure for eova_object
-- ----------------------------
DROP TABLE IF EXISTS `eova_object`;
CREATE TABLE `eova_object` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(100) NOT NULL COMMENT '对象编码',
  `name` varchar(100) NOT NULL COMMENT '对象名称',
  `view_name` varchar(255) default NULL COMMENT '查询数据视图',
  `table_name` varchar(255) default NULL COMMENT '保存数据主表',
  `pk_name` varchar(50) NOT NULL COMMENT '主键',
  `data_source` varchar(50) default 'main' COMMENT '数据源',
  `is_single` tinyint(1) default '1' COMMENT '是否单选',
  `is_celledit` tinyint(1) default '0' COMMENT '是否可行内编辑',
  `is_show_num` tinyint(1) default '1' COMMENT '是否显示行号',
  `is_first_load` tinyint(1) default '1' COMMENT '是否初始加载',
  `filter` varchar(500) default NULL COMMENT '初始数据过滤条件',
  `default_order` varchar(255) default NULL COMMENT '默认排序字段(desc)',
  `diy_card` varchar(255) default NULL COMMENT '自定义卡片面板',
  `diy_js` varchar(255) default NULL COMMENT '依赖JS文件',
  `biz_intercept` varchar(255) default NULL COMMENT '自定义业务拦截器',
  `view_sql` varchar(1000) default NULL COMMENT '视图SQL',
  `config` varchar(2000) default NULL COMMENT '拓展配置',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unique_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=1157 DEFAULT CHARSET=utf8 COMMENT='EOVA元对象';

-- ----------------------------
-- Records of eova_object
-- ----------------------------
INSERT INTO `eova_object` VALUES ('1', 'meta_template', '元对象模版数据', null, 'eova_template', 'id', 'eova', '1', '0', '1', '1', null, null, null, null, '', null, null);
INSERT INTO `eova_object` VALUES ('2', 'eova_menu_code', '菜单', '', 'eova_menu', 'id', 'eova', '0', '0', '1', '1', 'where parent_id <> 1 and id <> 1', '', null, '', 'com.eova.core.menu.MenuIntercept', null, '');
INSERT INTO `eova_object` VALUES ('3', 'eova_object_code', '对象', '', 'eova_object', 'id', 'eova', '0', '0', '1', '1', 'where id > 999', 'id desc', null, '', 'com.eova.core.object.ObjectIntercept', null, '');
INSERT INTO `eova_object` VALUES ('4', 'eova_field_code', '字段', '', 'eova_field', 'id', 'eova', '1', '1', '1', '1', '', 'fieldnum,order_num', null, '', '', null, null);
INSERT INTO `eova_object` VALUES ('5', 'eova_button_code', '按钮', '', 'eova_button', 'id', 'eova', '0', '0', '1', '1', 'where id > 999 and is_base = 0', 'id desc', null, '', '', null, '');
INSERT INTO `eova_object` VALUES ('6', 'eova_user_code', '用户', '', 'eova_user', 'id', 'eova', '1', '0', '1', '1', 'where rid in (select id from eova_role where lv > ${user.role.lv})', 'id desc', null, '', 'com.eova.user.UserIntercept', null, '');
INSERT INTO `eova_object` VALUES ('7', 'eova_role_code', '角色管理', '', 'eova_role', 'id', 'eova', '1', '0', '1', '1', '${user.role.lv} = 0 or ${user.role.lv} < lv', 'id desc', null, '', 'com.eova.core.role.RoleIntercept', null, null);
INSERT INTO `eova_object` VALUES ('8', 'eova_task_code', '定时调度', null, 'eova_task', 'id', 'eova', '1', '0', '1', '1', null, null, null, null, 'com.eova.core.task.TaskIntercept', null, null);
INSERT INTO `eova_object` VALUES ('9', 'eova_log_code', '操作日志', null, 'eova_log', 'id', 'eova', '1', '0', '1', '1', null, 'id desc', null, null, '', null, null);
INSERT INTO `eova_object` VALUES ('100', 'user_info_code', '用户详细信息', '', 'user_info', 'id', 'main', '1', '0', '1', '1', '', '', null, '/ui/js/diy/area.js', 'com.eova.user.UserInfoIntercept', null, null);
INSERT INTO `eova_object` VALUES ('1125', 'work_time', '进度时间', null, 'work_time', 'work_time_id', 'main', '1', '0', '1', '1', null, null, null, null, null, null, null);
INSERT INTO `eova_object` VALUES ('1126', 'class_info', '班级信息', '', 'class_info', 'class_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1127', 'subject', '专业信息', '', 'subject', 'subject_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1128', 'grade', '年级信息', '', 'grade', 'grade_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1129', 'admin', '管理员', '', 'admin', 'admin_id', 'main', '0', '0', '1', '1', '', '', null, '', 'com.eova.intercept.AdminUUIDIntercept', '', '');
INSERT INTO `eova_object` VALUES ('1131', 'teacher', '教师', '', 'teacher', 'teacher_id', 'main', '0', '0', '1', '1', '', '', null, '', 'com.eova.intercept.TeacherUUIDIntercept', '', '');
INSERT INTO `eova_object` VALUES ('1132', 'user', '用户', '', 'user', 'user_id', 'main', '0', '0', '1', '1', '', '', null, '', 'com.eova.intercept.MyUserIntercept', '', '');
INSERT INTO `eova_object` VALUES ('1133', 'roles', '角色', null, 'roles', 'roles_id', 'main', '1', '0', '1', '1', null, null, null, null, null, null, null);
INSERT INTO `eova_object` VALUES ('1135', 'dept', '部门', '', 'dept', 'dept_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1136', 'my_dicts', '字典表', null, 'dicts', 'id', 'main', '1', '0', '1', '1', null, null, null, null, null, null, null);
INSERT INTO `eova_object` VALUES ('1137', 'project', '课题', '', 'project', 'project_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1138', 'project_from', '课题来源', null, 'project_from', 'project_from_id', 'main', '1', '0', '1', '1', null, null, null, null, null, null, null);
INSERT INTO `eova_object` VALUES ('1139', 'ktbg', '开题报告', '', 'ktbg', 'ktbg_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1140', 'zqjc', '中期检查', '', 'zqjc', 'zqjc_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1141', 'inform', '通知公告', '', 'inform', 'inform_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1142', 'down', '下载文件', '', 'down', 'down_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1143', 'lunwen', '论文', '', 'lunwen', 'lunwen_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1147', 'mangsheng', '盲审', '', 'mangsheng', 'id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1148', 'dabian', '答辩成绩', '', 'dabian', 'id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1151', 'yansou', '验收小组', '', 'yansou_team', 'yansou_team_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1152', 'yansou_teacher', '验收小组成员', '', 'yansou_teacher', 'id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1153', 'mdb', '免答辩申请', '', 'mdb', 'mdb_id', 'main', '0', '0', '1', '1', '', '', null, '', '', '', '');
INSERT INTO `eova_object` VALUES ('1156', 'student', '学生', '', 'student', 'student_id', 'main', '0', '0', '1', '1', '', '', null, '', 'com.eova.intercept.StudentUUIDIntercept', '', '');

-- ----------------------------
-- Table structure for eova_role
-- ----------------------------
DROP TABLE IF EXISTS `eova_role`;
CREATE TABLE `eova_role` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL COMMENT '角色名',
  `info` varchar(255) default NULL COMMENT '角色描述',
  `lv` int(11) default '0' COMMENT '权限级别',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='EOVA角色';

-- ----------------------------
-- Records of eova_role
-- ----------------------------
INSERT INTO `eova_role` VALUES ('1', '超级管理员', '开发者权限(禁止作为业务权限)', '0');
INSERT INTO `eova_role` VALUES ('2', '管理员', '管理所有可用功能', '10');
INSERT INTO `eova_role` VALUES ('3', '测试组长', '测试小组的组长', '20');
INSERT INTO `eova_role` VALUES ('4', '测试通用', '测试通用权限', '30');

-- ----------------------------
-- Table structure for eova_role_btn
-- ----------------------------
DROP TABLE IF EXISTS `eova_role_btn`;
CREATE TABLE `eova_role_btn` (
  `id` int(11) NOT NULL auto_increment,
  `rid` int(11) NOT NULL COMMENT '角色',
  `bid` int(11) NOT NULL COMMENT '功能',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=855 DEFAULT CHARSET=utf8 COMMENT='EOVA角色按钮';

-- ----------------------------
-- Records of eova_role_btn
-- ----------------------------
INSERT INTO `eova_role_btn` VALUES ('379', '2', '1132');
INSERT INTO `eova_role_btn` VALUES ('384', '2', '100');
INSERT INTO `eova_role_btn` VALUES ('404', '2', '116');
INSERT INTO `eova_role_btn` VALUES ('405', '2', '112');
INSERT INTO `eova_role_btn` VALUES ('406', '2', '113');
INSERT INTO `eova_role_btn` VALUES ('407', '2', '110');
INSERT INTO `eova_role_btn` VALUES ('408', '2', '111');
INSERT INTO `eova_role_btn` VALUES ('415', '2', '1134');
INSERT INTO `eova_role_btn` VALUES ('416', '2', '1133');
INSERT INTO `eova_role_btn` VALUES ('417', '2', '1135');
INSERT INTO `eova_role_btn` VALUES ('422', '2', '129');
INSERT INTO `eova_role_btn` VALUES ('460', '1', '33');
INSERT INTO `eova_role_btn` VALUES ('474', '1', '43');
INSERT INTO `eova_role_btn` VALUES ('475', '1', '42');
INSERT INTO `eova_role_btn` VALUES ('476', '1', '41');
INSERT INTO `eova_role_btn` VALUES ('477', '1', '40');
INSERT INTO `eova_role_btn` VALUES ('481', '1', '22');
INSERT INTO `eova_role_btn` VALUES ('483', '1', '23');
INSERT INTO `eova_role_btn` VALUES ('485', '1', '25');
INSERT INTO `eova_role_btn` VALUES ('487', '1', '26');
INSERT INTO `eova_role_btn` VALUES ('489', '1', '27');
INSERT INTO `eova_role_btn` VALUES ('491', '1', '28');
INSERT INTO `eova_role_btn` VALUES ('493', '1', '29');
INSERT INTO `eova_role_btn` VALUES ('495', '1', '3');
INSERT INTO `eova_role_btn` VALUES ('496', '1', '1');
INSERT INTO `eova_role_btn` VALUES ('499', '1', '30');
INSERT INTO `eova_role_btn` VALUES ('500', '1', '7');
INSERT INTO `eova_role_btn` VALUES ('501', '1', '6');
INSERT INTO `eova_role_btn` VALUES ('502', '1', '32');
INSERT INTO `eova_role_btn` VALUES ('503', '1', '31');
INSERT INTO `eova_role_btn` VALUES ('504', '1', '4');
INSERT INTO `eova_role_btn` VALUES ('505', '1', '9');
INSERT INTO `eova_role_btn` VALUES ('506', '1', '8');
INSERT INTO `eova_role_btn` VALUES ('521', '1', '20');
INSERT INTO `eova_role_btn` VALUES ('522', '1', '1132');
INSERT INTO `eova_role_btn` VALUES ('527', '1', '100');
INSERT INTO `eova_role_btn` VALUES ('529', '1', '90');
INSERT INTO `eova_role_btn` VALUES ('548', '1', '88');
INSERT INTO `eova_role_btn` VALUES ('549', '1', '116');
INSERT INTO `eova_role_btn` VALUES ('550', '1', '112');
INSERT INTO `eova_role_btn` VALUES ('551', '1', '113');
INSERT INTO `eova_role_btn` VALUES ('552', '1', '110');
INSERT INTO `eova_role_btn` VALUES ('553', '1', '111');
INSERT INTO `eova_role_btn` VALUES ('560', '1', '82');
INSERT INTO `eova_role_btn` VALUES ('561', '1', '83');
INSERT INTO `eova_role_btn` VALUES ('562', '1', '80');
INSERT INTO `eova_role_btn` VALUES ('563', '1', '81');
INSERT INTO `eova_role_btn` VALUES ('564', '1', '86');
INSERT INTO `eova_role_btn` VALUES ('565', '1', '87');
INSERT INTO `eova_role_btn` VALUES ('566', '1', '84');
INSERT INTO `eova_role_btn` VALUES ('567', '1', '1134');
INSERT INTO `eova_role_btn` VALUES ('568', '1', '1133');
INSERT INTO `eova_role_btn` VALUES ('569', '1', '1135');
INSERT INTO `eova_role_btn` VALUES ('574', '1', '129');
INSERT INTO `eova_role_btn` VALUES ('589', '1', '45');
INSERT INTO `eova_role_btn` VALUES ('590', '1', '44');
INSERT INTO `eova_role_btn` VALUES ('600', '1', '1139');
INSERT INTO `eova_role_btn` VALUES ('601', '1', '1140');
INSERT INTO `eova_role_btn` VALUES ('602', '1', '1141');
INSERT INTO `eova_role_btn` VALUES ('603', '1', '1142');
INSERT INTO `eova_role_btn` VALUES ('604', '1', '1143');
INSERT INTO `eova_role_btn` VALUES ('605', '1', '1144');
INSERT INTO `eova_role_btn` VALUES ('606', '1', '1145');
INSERT INTO `eova_role_btn` VALUES ('636', '1', '1175');
INSERT INTO `eova_role_btn` VALUES ('637', '1', '1176');
INSERT INTO `eova_role_btn` VALUES ('638', '1', '1177');
INSERT INTO `eova_role_btn` VALUES ('639', '1', '1178');
INSERT INTO `eova_role_btn` VALUES ('640', '1', '1179');
INSERT INTO `eova_role_btn` VALUES ('641', '1', '1180');
INSERT INTO `eova_role_btn` VALUES ('642', '1', '1181');
INSERT INTO `eova_role_btn` VALUES ('643', '1', '1182');
INSERT INTO `eova_role_btn` VALUES ('644', '1', '1183');
INSERT INTO `eova_role_btn` VALUES ('645', '1', '1184');
INSERT INTO `eova_role_btn` VALUES ('646', '1', '1185');
INSERT INTO `eova_role_btn` VALUES ('647', '1', '1186');
INSERT INTO `eova_role_btn` VALUES ('648', '1', '1187');
INSERT INTO `eova_role_btn` VALUES ('649', '1', '1188');
INSERT INTO `eova_role_btn` VALUES ('650', '1', '1189');
INSERT INTO `eova_role_btn` VALUES ('651', '1', '1190');
INSERT INTO `eova_role_btn` VALUES ('652', '1', '1191');
INSERT INTO `eova_role_btn` VALUES ('653', '1', '1192');
INSERT INTO `eova_role_btn` VALUES ('654', '1', '1193');
INSERT INTO `eova_role_btn` VALUES ('655', '1', '1194');
INSERT INTO `eova_role_btn` VALUES ('656', '1', '1195');
INSERT INTO `eova_role_btn` VALUES ('682', '1', '1221');
INSERT INTO `eova_role_btn` VALUES ('683', '1', '1222');
INSERT INTO `eova_role_btn` VALUES ('684', '1', '1223');
INSERT INTO `eova_role_btn` VALUES ('685', '1', '1224');
INSERT INTO `eova_role_btn` VALUES ('686', '1', '1225');
INSERT INTO `eova_role_btn` VALUES ('687', '1', '1226');
INSERT INTO `eova_role_btn` VALUES ('688', '1', '1227');
INSERT INTO `eova_role_btn` VALUES ('689', '1', '1228');
INSERT INTO `eova_role_btn` VALUES ('690', '1', '1229');
INSERT INTO `eova_role_btn` VALUES ('691', '1', '1230');
INSERT INTO `eova_role_btn` VALUES ('692', '1', '1231');
INSERT INTO `eova_role_btn` VALUES ('693', '1', '1232');
INSERT INTO `eova_role_btn` VALUES ('694', '1', '1233');
INSERT INTO `eova_role_btn` VALUES ('695', '1', '1234');
INSERT INTO `eova_role_btn` VALUES ('696', '1', '1235');
INSERT INTO `eova_role_btn` VALUES ('697', '1', '1236');
INSERT INTO `eova_role_btn` VALUES ('698', '1', '1237');
INSERT INTO `eova_role_btn` VALUES ('699', '1', '1238');
INSERT INTO `eova_role_btn` VALUES ('700', '1', '1239');
INSERT INTO `eova_role_btn` VALUES ('701', '1', '1240');
INSERT INTO `eova_role_btn` VALUES ('702', '1', '1241');
INSERT INTO `eova_role_btn` VALUES ('703', '1', '1242');
INSERT INTO `eova_role_btn` VALUES ('704', '1', '1243');
INSERT INTO `eova_role_btn` VALUES ('705', '1', '1244');
INSERT INTO `eova_role_btn` VALUES ('706', '1', '1245');
INSERT INTO `eova_role_btn` VALUES ('707', '1', '1246');
INSERT INTO `eova_role_btn` VALUES ('708', '1', '1247');
INSERT INTO `eova_role_btn` VALUES ('709', '1', '1248');
INSERT INTO `eova_role_btn` VALUES ('710', '1', '1249');
INSERT INTO `eova_role_btn` VALUES ('711', '1', '1250');
INSERT INTO `eova_role_btn` VALUES ('712', '1', '1251');
INSERT INTO `eova_role_btn` VALUES ('713', '1', '1252');
INSERT INTO `eova_role_btn` VALUES ('714', '1', '1253');
INSERT INTO `eova_role_btn` VALUES ('715', '1', '1254');
INSERT INTO `eova_role_btn` VALUES ('716', '1', '1255');
INSERT INTO `eova_role_btn` VALUES ('717', '1', '1256');
INSERT INTO `eova_role_btn` VALUES ('718', '1', '1257');
INSERT INTO `eova_role_btn` VALUES ('719', '1', '1258');
INSERT INTO `eova_role_btn` VALUES ('720', '1', '1259');
INSERT INTO `eova_role_btn` VALUES ('721', '1', '1260');
INSERT INTO `eova_role_btn` VALUES ('722', '1', '1261');
INSERT INTO `eova_role_btn` VALUES ('723', '1', '1262');
INSERT INTO `eova_role_btn` VALUES ('724', '1', '1263');
INSERT INTO `eova_role_btn` VALUES ('725', '1', '1264');
INSERT INTO `eova_role_btn` VALUES ('726', '1', '1265');
INSERT INTO `eova_role_btn` VALUES ('727', '1', '1266');
INSERT INTO `eova_role_btn` VALUES ('728', '1', '1267');
INSERT INTO `eova_role_btn` VALUES ('729', '1', '1268');
INSERT INTO `eova_role_btn` VALUES ('730', '1', '1269');
INSERT INTO `eova_role_btn` VALUES ('731', '1', '1270');
INSERT INTO `eova_role_btn` VALUES ('732', '1', '1271');
INSERT INTO `eova_role_btn` VALUES ('733', '1', '1272');
INSERT INTO `eova_role_btn` VALUES ('734', '1', '1273');
INSERT INTO `eova_role_btn` VALUES ('735', '1', '1274');
INSERT INTO `eova_role_btn` VALUES ('736', '1', '1275');
INSERT INTO `eova_role_btn` VALUES ('737', '1', '1276');
INSERT INTO `eova_role_btn` VALUES ('738', '1', '1277');
INSERT INTO `eova_role_btn` VALUES ('739', '1', '1278');
INSERT INTO `eova_role_btn` VALUES ('740', '1', '1279');
INSERT INTO `eova_role_btn` VALUES ('741', '1', '1280');
INSERT INTO `eova_role_btn` VALUES ('742', '1', '1281');
INSERT INTO `eova_role_btn` VALUES ('743', '1', '1282');
INSERT INTO `eova_role_btn` VALUES ('744', '1', '1283');
INSERT INTO `eova_role_btn` VALUES ('745', '1', '1284');
INSERT INTO `eova_role_btn` VALUES ('746', '1', '1285');
INSERT INTO `eova_role_btn` VALUES ('747', '1', '1286');
INSERT INTO `eova_role_btn` VALUES ('748', '1', '1287');
INSERT INTO `eova_role_btn` VALUES ('749', '1', '1288');
INSERT INTO `eova_role_btn` VALUES ('750', '1', '1289');
INSERT INTO `eova_role_btn` VALUES ('751', '1', '1290');
INSERT INTO `eova_role_btn` VALUES ('752', '1', '1291');
INSERT INTO `eova_role_btn` VALUES ('753', '1', '1292');
INSERT INTO `eova_role_btn` VALUES ('754', '1', '1293');
INSERT INTO `eova_role_btn` VALUES ('755', '1', '1294');
INSERT INTO `eova_role_btn` VALUES ('756', '1', '1295');
INSERT INTO `eova_role_btn` VALUES ('757', '1', '1296');
INSERT INTO `eova_role_btn` VALUES ('758', '1', '1297');
INSERT INTO `eova_role_btn` VALUES ('759', '1', '1298');
INSERT INTO `eova_role_btn` VALUES ('760', '1', '1299');
INSERT INTO `eova_role_btn` VALUES ('761', '1', '1300');
INSERT INTO `eova_role_btn` VALUES ('762', '1', '1301');
INSERT INTO `eova_role_btn` VALUES ('763', '1', '1302');
INSERT INTO `eova_role_btn` VALUES ('764', '1', '1303');
INSERT INTO `eova_role_btn` VALUES ('765', '1', '1304');
INSERT INTO `eova_role_btn` VALUES ('773', '1', '1312');
INSERT INTO `eova_role_btn` VALUES ('774', '1', '1313');
INSERT INTO `eova_role_btn` VALUES ('775', '1', '1314');
INSERT INTO `eova_role_btn` VALUES ('776', '1', '1315');
INSERT INTO `eova_role_btn` VALUES ('777', '1', '1316');
INSERT INTO `eova_role_btn` VALUES ('778', '1', '1317');
INSERT INTO `eova_role_btn` VALUES ('779', '1', '1318');
INSERT INTO `eova_role_btn` VALUES ('780', '1', '1319');
INSERT INTO `eova_role_btn` VALUES ('781', '1', '1320');
INSERT INTO `eova_role_btn` VALUES ('782', '1', '1321');
INSERT INTO `eova_role_btn` VALUES ('783', '1', '1322');
INSERT INTO `eova_role_btn` VALUES ('784', '1', '1323');
INSERT INTO `eova_role_btn` VALUES ('785', '1', '1324');
INSERT INTO `eova_role_btn` VALUES ('786', '1', '1325');
INSERT INTO `eova_role_btn` VALUES ('787', '1', '1326');
INSERT INTO `eova_role_btn` VALUES ('788', '1', '1327');
INSERT INTO `eova_role_btn` VALUES ('789', '1', '1328');
INSERT INTO `eova_role_btn` VALUES ('790', '1', '1329');
INSERT INTO `eova_role_btn` VALUES ('791', '1', '1330');
INSERT INTO `eova_role_btn` VALUES ('792', '1', '1331');
INSERT INTO `eova_role_btn` VALUES ('793', '1', '1332');
INSERT INTO `eova_role_btn` VALUES ('794', '1', '1333');
INSERT INTO `eova_role_btn` VALUES ('795', '1', '1334');
INSERT INTO `eova_role_btn` VALUES ('796', '1', '1335');
INSERT INTO `eova_role_btn` VALUES ('797', '1', '1336');
INSERT INTO `eova_role_btn` VALUES ('798', '1', '1337');
INSERT INTO `eova_role_btn` VALUES ('799', '1', '1338');
INSERT INTO `eova_role_btn` VALUES ('800', '1', '1339');
INSERT INTO `eova_role_btn` VALUES ('819', '1', '1358');
INSERT INTO `eova_role_btn` VALUES ('820', '1', '1359');
INSERT INTO `eova_role_btn` VALUES ('821', '1', '1360');
INSERT INTO `eova_role_btn` VALUES ('822', '1', '1361');
INSERT INTO `eova_role_btn` VALUES ('823', '1', '1362');
INSERT INTO `eova_role_btn` VALUES ('824', '1', '1363');
INSERT INTO `eova_role_btn` VALUES ('825', '1', '1364');
INSERT INTO `eova_role_btn` VALUES ('826', '1', '1365');
INSERT INTO `eova_role_btn` VALUES ('827', '1', '1366');
INSERT INTO `eova_role_btn` VALUES ('828', '1', '1367');
INSERT INTO `eova_role_btn` VALUES ('829', '1', '1368');
INSERT INTO `eova_role_btn` VALUES ('830', '1', '1369');
INSERT INTO `eova_role_btn` VALUES ('831', '1', '1370');
INSERT INTO `eova_role_btn` VALUES ('832', '1', '1371');
INSERT INTO `eova_role_btn` VALUES ('833', '1', '1372');
INSERT INTO `eova_role_btn` VALUES ('834', '1', '1373');
INSERT INTO `eova_role_btn` VALUES ('835', '1', '1374');
INSERT INTO `eova_role_btn` VALUES ('836', '1', '1375');
INSERT INTO `eova_role_btn` VALUES ('837', '1', '1376');
INSERT INTO `eova_role_btn` VALUES ('838', '1', '1377');
INSERT INTO `eova_role_btn` VALUES ('839', '1', '1378');
INSERT INTO `eova_role_btn` VALUES ('840', '1', '1379');
INSERT INTO `eova_role_btn` VALUES ('841', '1', '1380');
INSERT INTO `eova_role_btn` VALUES ('842', '1', '1381');
INSERT INTO `eova_role_btn` VALUES ('843', '1', '1382');
INSERT INTO `eova_role_btn` VALUES ('844', '1', '1383');
INSERT INTO `eova_role_btn` VALUES ('845', '1', '1384');
INSERT INTO `eova_role_btn` VALUES ('846', '1', '1385');
INSERT INTO `eova_role_btn` VALUES ('847', '1', '1386');
INSERT INTO `eova_role_btn` VALUES ('848', '1', '1387');
INSERT INTO `eova_role_btn` VALUES ('849', '1', '1388');
INSERT INTO `eova_role_btn` VALUES ('850', '1', '1389');
INSERT INTO `eova_role_btn` VALUES ('851', '1', '1390');
INSERT INTO `eova_role_btn` VALUES ('852', '1', '1391');
INSERT INTO `eova_role_btn` VALUES ('853', '1', '1392');
INSERT INTO `eova_role_btn` VALUES ('854', '1', '1393');

-- ----------------------------
-- Table structure for eova_task
-- ----------------------------
DROP TABLE IF EXISTS `eova_task`;
CREATE TABLE `eova_task` (
  `id` int(11) NOT NULL auto_increment,
  `state` int(1) NOT NULL default '0' COMMENT '状态：0=停止，1=启动',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `exp` varchar(50) NOT NULL COMMENT '表达式',
  `clazz` varchar(255) NOT NULL COMMENT '实现类',
  `info` varchar(255) default NULL COMMENT '说明',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='EOVA任务';

-- ----------------------------
-- Records of eova_task
-- ----------------------------
INSERT INTO `eova_task` VALUES ('1', '0', '每分', '0 0/1 * * * ?', 'com.oss.job.EveryMinJob', '每分钟来一发');
INSERT INTO `eova_task` VALUES ('2', '0', '每时', '0 0 0/1 * * ?', 'com.oss.job.EveryHourJob', '每小时统计一次');
INSERT INTO `eova_task` VALUES ('12', '0', '每天', '59 59 23 * * ?', 'com.oss.job.EveryDayJob', '每天23点59分59秒跑一下');

-- ----------------------------
-- Table structure for eova_user
-- ----------------------------
DROP TABLE IF EXISTS `eova_user`;
CREATE TABLE `eova_user` (
  `id` int(11) NOT NULL auto_increment,
  `login_id` varchar(30) default NULL COMMENT '帐号',
  `login_pwd` varchar(50) default NULL COMMENT '密码',
  `rid` int(11) NOT NULL default '0' COMMENT '角色ID',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='EOVA用户';

-- ----------------------------
-- Records of eova_user
-- ----------------------------
INSERT INTO `eova_user` VALUES ('1', 'eova', '89BDF69372C2EF53EA409CDF020B5694', '1');
INSERT INTO `eova_user` VALUES ('2', 'admin', '89BDF69372C2EF53EA409CDF020B5694', '2');
INSERT INTO `eova_user` VALUES ('3', 'test', '89BDF69372C2EF53EA409CDF020B5694', '3');
INSERT INTO `eova_user` VALUES ('4', 'test1', '89BDF69372C2EF53EA409CDF020B5694', '4');
INSERT INTO `eova_user` VALUES ('5', 'test001', 'BE88DFE624999638495B304548570AEB', '2');
INSERT INTO `eova_user` VALUES ('7', 'test001', '89BDF69372C2EF53EA409CDF020B5694', '2');

-- ----------------------------
-- Table structure for eova_widget
-- ----------------------------
DROP TABLE IF EXISTS `eova_widget`;
CREATE TABLE `eova_widget` (
  `id` int(11) NOT NULL auto_increment,
  `type` int(5) NOT NULL default '1' COMMENT '控件类型：1=EOVA控件，2=DIY控件',
  `value` varchar(50) NOT NULL COMMENT '控件值',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `version` float(5,1) default '1.0' COMMENT '版本号',
  `path` varchar(50) default NULL COMMENT '路径',
  `description` varchar(4000) default NULL COMMENT '介绍',
  `config` varchar(4000) default NULL COMMENT '控件配置信息JSON',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='EOVA插件';

-- ----------------------------
-- Records of eova_widget
-- ----------------------------
INSERT INTO `eova_widget` VALUES ('1', '1', '下拉框', '下拉框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('2', '1', '查找框', '查找框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('3', '1', '文本框', '文本框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('4', '1', '文本域', '文本域', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('5', '1', '编辑框', '编辑框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('6', '1', 'JSON框', 'JSON框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('7', '1', '时间框', '时间框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('8', '1', '日期框', '日期框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('9', '1', '布尔框', '布尔框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('10', '1', '图片框', '图片框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('11', '1', '文件框', '文件框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('12', '1', '图标框', '图标框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('13', '1', '自增框', '自增框', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('14', '1', '下拉树', '下拉树', '1.0', '', '', null);
INSERT INTO `eova_widget` VALUES ('30', '2', '密码框', '密码框', '1.0', '/widget/password/index.html', '我的密码框，系统不给，自己造一个，大家一起爽歪歪', null);
INSERT INTO `eova_widget` VALUES ('31', '2', '数字框', '数字框', '1.0', '/widget/number/index.html', 'number', null);
INSERT INTO `eova_widget` VALUES ('32', '2', '颜色框', '颜色框', '1.0', '/widget/color/index.html', 'color', null);
INSERT INTO `eova_widget` VALUES ('33', '2', '复选框', '复选框', '1.0', '/widget/check/index.html', '下拉变多复选框', null);

-- ----------------------------
-- Table structure for mymenu
-- ----------------------------
DROP TABLE IF EXISTS `mymenu`;
CREATE TABLE `mymenu` (
  `id` int(11) NOT NULL auto_increment COMMENT '主键',
  `_id` varchar(255) NOT NULL COMMENT '公司id',
  `company_name` varchar(255) NOT NULL COMMENT '公司名',
  `type` varchar(255) NOT NULL COMMENT '类别',
  `url` varchar(255) NOT NULL COMMENT 'office路径',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mymenu
-- ----------------------------
INSERT INTO `mymenu` VALUES ('1', '3877b5a0-9859-11e7-9c24-5bad5f3dd5dc', '嘉兴市豪宇纺织有限公司', 'bzz', '/office/xls/bz.htm');
