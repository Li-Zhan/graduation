package com.oss.office.xls;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import com.eova.common.base.BaseModel;
import com.eova.common.utils.util.RandomUtil;
import com.eova.model.Menu;
import com.eova.template.office.OfficeIntercept;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;

/**
 * 下载Excel的拦截器
 * @author 李展
 *
 */
public class Xls1Intercept extends OfficeIntercept {

	@Override
	public void init(Controller ctrl, HashMap<String, Object> data, BaseModel menu) throws Exception {

		String _id = menu.getStr("_id");
		String sql="";
		try {
			Properties properties=new Properties();
			properties.load(this.getClass().getClassLoader().getResourceAsStream("sql.properties"));
			//sql=properties.getProperty("bzryp");
			sql=properties.getProperty(menu.getStr("type"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("SQL:"+sql);
		
/*		if(!sql.isEmpty()&&sql!=null) {
			sql+=" AND b1._id = ?";
		}*/
		
		//使用query方法查竟然会报错,需要使用find
//		List<Record> bzs = Db.find(sql,"758087162");
		List<Record> bzs = Db.find(sql,_id);
		System.out.println(bzs.get(0));
		data.put("list", bzs);
/*		data.put("tbrq_n", bzs.get(0).get("tbrq_n"));
		data.put("tbrq_y", bzs.get(0).get("tbrq_y"));
		data.put("tbrq_r", bzs.get(0).get("tbrq_r"));
		data.put("tbxq_sj",bzs.get(0).get("tbxq_sj"));
		data.put("tbxq_xj",bzs.get(0).get("tbxq_xj"));*/
		
	}
}
