package com.eova.user;

import com.eova.aop.AopContext;
import com.eova.aop.MetaObjectIntercept;
import com.jfinal.plugin.activerecord.Db;

public class UserTest extends MetaObjectIntercept{

	
	@Override
	public void queryBefore(AopContext ac) throws Exception {
		System.out.println("^_^-------------------------");
		super.queryBefore(ac);
	}


}
