package com.eova.model;

import com.eova.common.base.BaseModel;

/**
 * 下载Excel的自定义按钮(维护office路径,公司名,公司id,类别之间的关系)
 * @author 李展
 *
 */
public class MyMenu extends BaseModel<MyMenu>{

	private static final long serialVersionUID = 1L;
	
	public static final  MyMenu dao=new MyMenu();
	
	/**
	 * 获取office路径
	 */
	public String getUrl() {
		return this.getStr("url");
	}
	
	/**
	 * 获得公司名
	 */
	public String getCompanyName() {
		return this.getStr("company_name");
	}
	
	/**
	 * 获得公司id
	 */
	public String getCompanyId() {
		return this.getStr("_id");
	}
	
	/**
	 * 获得类别
	 */
	public String getType() {
		return this.getStr("type");
	}

}
