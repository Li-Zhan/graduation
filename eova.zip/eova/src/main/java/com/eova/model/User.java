package com.eova.model;

import com.eova.common.base.BaseModel;

/**
 * 
 * @author 李展
 *
 */
public class User extends BaseModel<User> {

	private static final long serialVersionUID = 8762093704834013009L;

	public static final User dao = new User();

	public Role role;
	
	public int getRid(){
		return 1;
	}
	
	public void init() {
		this.role = Role.dao.findById(1);
	}
	
	/**
	 * 是否超级管理员
	 * @return
	 */
	public boolean isAdmin(){
		return getIsAdmin();
	}
	
	// 为兼容模版取值
	public boolean getIsAdmin(){
		if (this.getInt("user_roles")==3) {
			return true;
		}
		return false;
	}

	public User getByLoginId(String loginId) {
		return this.findFirst("select * from user where user_account = ?", loginId);
	}
	
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

}