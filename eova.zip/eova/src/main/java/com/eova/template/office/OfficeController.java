/**
 * Copyright (c) 2013-2016, Jieven. All rights reserved.
 *
 * Licensed under the GPL license: http://www.gnu.org/licenses/gpl.txt
 * To use it on other terms please contact us at 1623736450@qq.com
 */
package com.eova.template.office;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.eova.common.Easy;
import com.eova.common.render.OfficeRender;
import com.eova.model.Menu;
import com.eova.model.MyMenu;
import com.eova.template.common.util.TemplateUtil;
import com.jfinal.core.Controller;
import com.jfinal.kit.PathKit;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;

/**
 * 业务模版：Office
 * 
 * @author 李展
 * 
 */
public class OfficeController extends Controller {

	final Controller ctrl = this;

	/** 自定义拦截器 **/
	protected OfficeIntercept intercept = null;

	public void list() {

		String menuCode = this.getPara(0);

		setAttr("menuCode", menuCode);

		render("/eova/template/office/list.html");
	}

	// 显示文档
	public void show() throws Exception {
		String menuCode = this.getPara(0);

		Menu menu = Menu.dao.findByCode(menuCode);
		String url = menu.getStr("url");

		intercept = TemplateUtil.initIntercept(menu.getBizIntercept());

		HashMap<String, Object> data = new HashMap<>();

		if (intercept != null) {
			try {
				intercept.init(ctrl, data, menu);
			} catch (Exception e) {
				renderText(e.getMessage());
				return;
			}
		}

		for (String key : data.keySet()) {
			Object o = data.get(key);
			setAttr(key, o);
		}

		render(url);
	}

	// 下载文档
	public void file() throws Exception {

		String menuCode = this.getPara(0);

		Menu menu = Menu.dao.findByCode(menuCode);
		String url = menu.getStr("url");

		// PathKit.getRootClassPath()
		String path = PathKit.getWebRootPath() + url;

		intercept = TemplateUtil.initIntercept(menu.getBizIntercept());

		HashMap<String, Object> data = new HashMap<>();

		String fileType = menu.getConfig().getParams().getString("office_type");
		String fileName = menu.getStr("name") + '.' + fileType;

		if (intercept != null) {
			try {
				intercept.init(ctrl, data, menu);
			} catch (Exception e) {
				renderJson(new Easy(e.getMessage()));
				return;
			}
		}

		render(new OfficeRender(fileType, fileName, path, data));
	}
	
	
	/**
	 * 下载Excel
	 * @throws Exception
	 */
	public void downloadExcel() throws Exception {
		
		//获得类别和公司id
//		String type = this.getPara("type");
		String _id = this.getPara("_id");

//		MyMenu myMenu = MyMenu.dao.queryByCache("select * from mymenu where type=? and _id=?", type, _id).get(0);
		MyMenu myMenu = MyMenu.dao.queryFisrtByCache("select * from mymenu where _id=?", _id);

		if(myMenu==null) {
			return;
		}
		
		// PathKit.getRootClassPath()
		String path= PathKit.getWebRootPath() + myMenu.getUrl();

		//intercept = TemplateUtil.initIntercept(menu.getBizIntercept());
		intercept = TemplateUtil.initIntercept("com.oss.office.xls.Xls1Intercept");

		HashMap<String, Object> data = new HashMap<>();

		String fileType = "xls";
		String fileName =myMenu.getCompanyName() + '.' + fileType;

		if (intercept != null) {
			try {
				intercept.init(ctrl, data, myMenu);
			} catch (Exception e) {
				renderJson(new Easy(e.getMessage()));
				return;
			}
		}

			render(new OfficeRender(fileType, fileName, path, data));
	}
	
	
	//获得公司名
	public void getCompanyName() {
/*		System.out.println("!!!!!"+this.getPara(0));
		List<Record> companies = Db.find("SELECT b1._id,b1.dwmc FROM jj_bzryp b1,jj_bzrypxq b2 WHERE b2._fk_jj_bzryp_id = b1._id");
		System.out.println("~~~~"+companies.get(0).get("_id"));
		renderJson(companies);*/
		
		String sql="";
		Properties properties=new Properties();
		try {
			properties.load(this.getClass().getClassLoader().getResourceAsStream("sql.properties"));
			sql=properties.getProperty(this.getPara("type"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(!sql.isEmpty()&&sql!=null) {
			sql=sql.replaceAll("and", "AND").substring(0, sql.indexOf("AND"));
		}
		
		List<Record> list = Db.find(sql);
/*		List<MyMenu> companies=new ArrayList<MyMenu>();
		Record record=list.get(0);
		record.get("_id");
		record.get("dwmc");
		for (Record record : list) {
			MyMenu menu=new MyMenu();
			menu.set("_id", record.get("_id"));
			menu.set("dwmc", record.get("dwmc"));
			companies.add(menu);
		}*/
		renderJson(list);
		
	}
	
	//获得某公司的类别
/*	public void getType() {
		String _id=this.getPara("_id");
		//String company_name=this.getPara("company_name");
		MyMenu myMenu=MyMenu.dao.queryFisrtByCache("select mymenu.type from mymenu where _id=? ", _id,company_name);
		//要想不弹出那个恶心的错误弹窗,需将返回的数据作为Easy的msg属性返回
		renderJson(new Easy(myMenu.getType(),true));
	}*/

}