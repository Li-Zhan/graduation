package com.eova.intercept;

import java.util.UUID;

import com.eova.aop.AopContext;
import com.eova.aop.MetaObjectIntercept;

public class StudentUUIDIntercept extends MetaObjectIntercept {
	
	@Override
	public String addBefore(AopContext ac) throws Exception {
		ac.record.set("student_id", UUID.randomUUID().toString().replaceAll("-", ""));
		ac.record.remove("teacher_id");
		return super.addBefore(ac);
	}

}
