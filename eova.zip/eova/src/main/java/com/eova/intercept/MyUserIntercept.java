package com.eova.intercept;

import java.util.UUID;
import com.eova.aop.AopContext;
import com.eova.aop.MetaObjectIntercept;
import com.eova.common.utils.EncryptUtil;

public class MyUserIntercept extends MetaObjectIntercept {
	
	
	@Override
	public String addBefore(AopContext ac) throws Exception {
		ac.record.set("user_password", EncryptUtil.getMd5(ac.record.getStr("user_password")));
		ac.record.set("user_id", UUID.randomUUID().toString().replaceAll("-", ""));
		return super.addBefore(ac);
	}
	
	
	@Override
	public String updateBefore(AopContext ac) throws Exception {
		ac.record.set("user_password", EncryptUtil.getMd5(ac.record.getStr("user_password")));
		return super.updateBefore(ac);
	}


}
