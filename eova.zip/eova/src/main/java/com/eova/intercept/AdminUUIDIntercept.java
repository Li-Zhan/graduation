package com.eova.intercept;

import java.util.UUID;

import com.eova.aop.AopContext;
import com.eova.aop.MetaObjectIntercept;

public class AdminUUIDIntercept extends MetaObjectIntercept {
	
	@Override
	public String addBefore(AopContext ac) throws Exception {
		ac.record.set("admin_id", UUID.randomUUID().toString().replaceAll("-", ""));
		return super.addBefore(ac);
	}

}
