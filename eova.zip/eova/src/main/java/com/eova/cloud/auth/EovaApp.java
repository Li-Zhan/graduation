package com.eova.cloud.auth;
public class EovaApp {}