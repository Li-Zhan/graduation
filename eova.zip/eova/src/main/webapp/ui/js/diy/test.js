$(document).ready(function(){
	alert('我是从 /ui/js/test.js,产生的弹窗事件，仅用于测试菜单的自定义JS依赖');
	
	
});