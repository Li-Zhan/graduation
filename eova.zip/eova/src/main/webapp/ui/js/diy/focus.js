$(document).ready(function(){
	$('#id').eovatext().$textbox.focus();
});